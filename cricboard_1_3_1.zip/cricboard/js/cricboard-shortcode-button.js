(function() {
    tinymce.create('tinymce.plugins.leaderboard', {
        init : function(ed, url) {
            
            ed.addButton('leaderboard', {
                title : 'Insert Leaderboard',
                image : url + '/leaderboard_sc.png',
                onclick : function() {
                    ed.selection.setContent('[leaderboard]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.create('tinymce.plugins.run_scorer', {
        init : function(ed, url) {
            
            ed.addButton('run_scorer', {
                title : 'Insert Top Run Scorer',
                image : url + '/run_scorer_sc.png',
                onclick : function() {
                    ed.selection.setContent('[run_scorer]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.create('tinymce.plugins.wicket_taker', {
        init : function(ed, url) {
            ed.addButton('wicket_taker', {
                title : 'Insert Leading Wicket Taker',
                image : url + '/wicket_taker_sc.png',
                onclick : function() {
                    ed.selection.setContent('[wicket_taker]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.create('tinymce.plugins.deadline', {
        init : function(ed, url) {
            ed.addButton('deadline', {
                title : 'Insert Deadline Timer',
                image : url + '/deadline_sc.png',
                onclick : function() {
                    ed.selection.setContent('[deadline]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.create('tinymce.plugins.accordion_start', {
        init : function(ed, url) {
            ed.addButton('accordion_start', {
                title : 'Insert Accordion Start',
                image : url + '/accordion_start_sc.png',
                onclick : function() {
                    ed.selection.setContent('[accordion_start title=""]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.create('tinymce.plugins.accordion_end', {
        init : function(ed, url) {
            ed.addButton('accordion_end', {
                title : 'Insert Accordion End',
                image : url + '/accordion_end_sc.png',
                onclick : function() {
                    ed.selection.setContent('[accordion_end]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('leaderboard', tinymce.plugins.leaderboard);
    tinymce.PluginManager.add('run_scorer', tinymce.plugins.run_scorer);
    tinymce.PluginManager.add('wicket_taker', tinymce.plugins.wicket_taker);
    tinymce.PluginManager.add('deadline', tinymce.plugins.deadline);
    tinymce.PluginManager.add('accordion_start', tinymce.plugins.accordion_start);
    tinymce.PluginManager.add('accordion_end', tinymce.plugins.accordion_end);
})();


