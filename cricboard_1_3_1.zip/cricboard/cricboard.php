<?php
/*
Plugin Name: Cricboard
Plugin URI: http://wordpress.org/plugins/cricboard/
Description: Plugin to maintain leaderboards in online cricket leagues
Author: itnicks
Author URI: http://www.itnicks.com/
Version: 1.3.1
Text Domain: cricboard
*/

//Constants
define('CRICBOARD_VERSION', '1.3.1');
define('CRICBOARD_STATS_LIMIT', 10);
define('CRICBOARD_MAX_GAMES', 4);
define('CRICBOARD_WIN_POINTS', 5);
define('CRICBOARD_PART_POINTS', 0);
define('CRICBOARD_BID_POINTS', 0);
define('CRICBOARD_MAX_OVERS', 20);
define('CRICBOARD_MAX_WICKETS', 10);

//Check if user is logged in else redirect user to login URL
function cricboard_check_login() {
    if(!is_user_logged_in() && $GLOBALS['pagenow'] != 'wp-login.php') auth_redirect();
}
//add_action('init', 'cricboard_check_login');

/**
 * Get unique ID.
 *
 */
function cricboard_unique_id($prefix = '') {
	static $id_counter = 0;
	if (function_exists('wp_unique_id')) {
		return wp_unique_id($prefix);
	}
	return $prefix . (string) ++$id_counter;
}

require(plugin_dir_path(__FILE__).'api/vendor/autoload.php');
require_once(plugin_dir_path(__FILE__).'cricboard_teams.php');
require_once(plugin_dir_path(__FILE__).'cricboard_settings.php');
require_once(plugin_dir_path(__FILE__).'cricboard_post_types.php');
require_once(plugin_dir_path(__FILE__).'cricboard_init.php');
require_once(plugin_dir_path(__FILE__).'cricboard_html_functions.php');
require_once(plugin_dir_path(__FILE__).'cricboard_data_functions.php');
require_once(plugin_dir_path(__FILE__).'cricboard_shortcodes.php');
require_once(plugin_dir_path(__FILE__).'cricboard_comment_functions.php');
require_once(plugin_dir_path(__FILE__).'cricboard_admin_functions.php');

function cricboard_comment_template( $comment_template ) {
    if(get_post_type(get_the_ID()) == 'league')
        return dirname(__FILE__) . '/cricboard-comments.php';
    else
        return $comment_template;
}
add_filter( "comments_template", "cricboard_comment_template" );

?>