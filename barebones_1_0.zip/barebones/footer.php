<?php
/**
 * The template for displaying the footer
 *
 */
?>
    <footer class="site-footer">
        <div class="site-social"></div>
        <div class="site-credit"><?php _e('Copyright','barebones'); ?> &copy; <?php bloginfo('name'); ?></div>
    </footer>
    
</div> <!-- #page -->
<div class="bgfreeze"></div>
<?php get_template_part('template-parts/nav/responsive-sidebar'); ?>
<?php wp_footer(); ?>
</body>
</html>