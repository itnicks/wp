<?php
/**
 * Theme Customizer
 */

function barebones_customize_register($wp_customize) {	

	//Link color setting
	$wp_customize->add_setting(
		'link_color',
		array(
			'default'           => '#52C8E5',
			'transport'         => 'refresh',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_control ( 
	new WP_Customize_Color_Control ( 
		$wp_customize, 
		'link_color', 
		array(
			'label'      => __('Link Color', 'barebones'),
			'section'    => 'colors',
			'settings'   => 'link_color',
		)) 
	);
	
	//Add theme options section
	$wp_customize->add_section('theme_options_section', array(
	    'priority' => 30,
	    'capability' => 'edit_theme_options',
	    'title' => __('Theme Options', 'barebones'),
	));
	
	//Show/hide author bio
	$wp_customize->add_setting('toggle_author_bio', array(
        'default' => '',
        'type' => 'theme_mod',
        'capability' => 'edit_theme_options',
        'transport' => 'refresh',
        'sanitize_callback' => 'barebones_sanitize_checkbox',
    ));

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'toggle_author_bio',
			array(
				'label'     => __('Show Author Bio (on single posts)', 'barebones'),
				'section'   => 'theme_options_section',
				'settings'  => 'toggle_author_bio',
				'type'      => 'checkbox',
			)
		)
	);
	
	//Show/hide post navigation
	$wp_customize->add_setting('show_post_nav', array(
        'default' => '',
        'type' => 'theme_mod',
        'capability' => 'edit_theme_options',
        'transport' => 'refresh',
        'sanitize_callback' => 'barebones_sanitize_checkbox',
    ));

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'show_post_nav',
			array(
				'label'     => __('Show Post Navigation (on single posts)', 'barebones'),
				'section'   => 'theme_options_section',
				'settings'  => 'show_post_nav',
				'type'      => 'checkbox',
			)
		)
	);
	
}
add_action('customize_register', 'barebones_customize_register');

/**
 * Apply customizer css
 */
function barebones_customize_css() {
	$link_color = get_theme_mod('link_color');
	?>
	<style type="text/css">
		
	</style>
	<?php
}
add_action('wp_head', 'barebones_customize_css');

/**
 * Sanitize checkboxes
 */
function barebones_sanitize_checkbox($input) {
	if($input != '' && $input != '1') return '';
	return $input;
}