/**
 * Theme JavaScript functions
 */
(function( $ ) {
    
    /**************** Navigation JS Start ****************/
    
    $('.responsive-menu a').after('<span class="responsive-nav-child-toggle"></span>');
    $('.responsive-menu li.menu-item-has-children > .responsive-nav-child-toggle').append('<span class="theme-icon theme-icon-chevron-right"></span>');
    
    $('.top-menu > li.menu-item-has-children > a').append('<span class="top-nav-child-toggle theme-icon theme-icon-chevron-down"></span>');
    $('.top-menu li li.menu-item-has-children > a').append('<span class="top-nav-child-toggle theme-icon theme-icon-chevron-right"></span>');
    $('.top-menu > li.menu-item-has-children').hover(function() {
        $(this).children('a').children('.top-nav-child-toggle').removeClass('theme-icon-chevron-down');
        $(this).children('a').children('.top-nav-child-toggle').addClass('theme-icon-chevron-up');
    }, function() {
        $(this).children('a').children('.top-nav-child-toggle').removeClass('theme-icon-chevron-up');
        $(this).children('a').children('.top-nav-child-toggle').addClass('theme-icon-chevron-down');
    });
    
    //Toggle responsive nav sub menu
    $('.responsive-nav-child-toggle').click(function() {
        if($(this).parent().children('ul').css('display') == 'none') {
            $(this).parent().children('ul').slideDown(500);
            $(this).children('.theme-icon').removeClass('theme-icon-chevron-right');
            $(this).children('.theme-icon').addClass('theme-icon-chevron-down');
        } else {
            $(this).parent().find('ul').slideUp(500);
            $(this).parent().find('.theme-icon').removeClass('theme-icon-chevron-down');
            $(this).parent().find('.theme-icon').addClass('theme-icon-chevron-right');
        }
    });
    
    $('li.menu-item-has-children a').each(function() {
        if($(this).attr('href') == '#' || $(this).attr('href') == 'javascript:void(0)') {
            $(this).addClass('parent-noclick');
        }
    });
    $('.parent-noclick').click(function() {
        if($(this).parent().children('ul').css('display') == 'none') {
            $(this).parent().children('ul').slideDown(500);
            $(this).parent().children('.responsive-nav-child-toggle').children('.theme-icon').removeClass('theme-icon-chevron-right');
            $(this).parent().children('.responsive-nav-child-toggle').children('.theme-icon').addClass('theme-icon-chevron-down');
        } else {
            $(this).parent().find('ul').slideUp(500);
            $(this).parent().find('.theme-icon').removeClass('theme-icon-chevron-down');
            $(this).parent().find('.theme-icon').addClass('theme-icon-chevron-right');
        }
    });

    $('#menu-open').click(function() {
        $('body').css('overflow', 'hidden');
        $('#responsive-sidebar').animate({right: "0"}, 500);
        $('.bgfreeze').show();
        
    });
    
    $('#menu-close').click(function() {
        $('#responsive-sidebar').animate({right: "-100%"}, 500);
        $('body').css('overflow', 'auto');
        $('.bgfreeze').hide();
    });
    
    /**************** Navigation JS End **************/
    
})( jQuery );