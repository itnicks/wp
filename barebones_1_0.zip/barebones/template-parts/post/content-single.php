<?php
/**
 * Template part for displaying posts
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <?php barebones_post_thumbnail(); ?>
        <?php
            //barebones_category_list();
            the_title('<h1 class="entry-title">', '</h1>');
        ?>
        <div class="entry-meta">
            <?php barebones_posted_on(); ?>
            <?php barebones_posted_by(); ?>
            <?php barebones_comment_link(); ?>
        </div>
    </header>
    <div class="entry-content">
		<?php
        the_content(__('Continue Reading','barebones'));    
        wp_link_pages(array(
            'before'      => '<div class="page-links">',
            'after'       => '</div>',
            'link_before' => '<span class="page-number">',
            'link_after'  => '</span>',
        ));
		?>
	</div><!-- .entry-content -->
    <footer class="entry-footer">
        <?php if(get_theme_mod('toggle_author_bio')) barebones_author_bio(); ?>
        <?php if(get_theme_mod('show_post_nav')) barebones_post_navigation(); ?>
    </footer>
</article>