<?php
/**
 * Template part for displaying posts
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">        
        <?php
            the_title(sprintf('<h3 class="entry-title"><a href="%s" rel="bookmark">', esc_url(get_permalink())), '</a></h3>');
        ?>
        <div class="entry-meta">
            <?php barebones_posted_on(); ?>
            <?php barebones_posted_by(); ?>
            <?php barebones_comment_link(true); ?>
        </div>
        <?php barebones_post_thumbnail(); ?>
    </header>    
    <div class="entry-content">
		<?php
        the_excerpt();
		?>
	</div><!-- .entry-content -->
</article>