<?php
/**
 * Header template
 */
?>
<header id="masthead" class="site-header">
    <!-- Logo -->
    <?php barebones_custom_logo('<div class="site-logo">', '</div>'); ?>
    
    <!-- Site title and description -->
    <div class="site-info">        
        <?php
            $blog_info = get_bloginfo('name');
            $description = get_bloginfo('description');
            if (!empty( $blog_info)):
                if (is_front_page() && is_home()) :
                ?>
                <h1 class="site-title"><a href="<?php echo esc_url(home_url( '/')); ?>" rel="home"><?php bloginfo('name'); ?></a></h1>
                <?php
                    if($description):
                    ?>
                    <h2 class="site-description"><?php echo $description; ?></h2>
                    <?php
                    endif;
                else:
                ?>
                <h4 class="site-title"><a href="<?php echo esc_url(home_url( '/')); ?>" rel="home"><?php bloginfo('name'); ?></a></h4>
                <?php
                    if($description):
                    ?>
                    <p class="site-description"><?php echo $description; ?></p>
                    <?php
                    endif;
                endif;
            endif;
        ?>
    </div>
    
    <!-- dropdown nav -->
    <?php barebones_navigation('primary', 'top-menu', 'top-menu', 'top-menu-container'); ?>
    
    <!-- responsive menu button -->
    <div class="site-buttons">
        <a id="menu-open" href="javascript:void(0)"><span class="theme-icon theme-icon-menu"></span></a>
    </div>
</header>