<?php
/**
 * Responsive Nav template
 */
?>
<div id="responsive-sidebar">
    <a id="menu-close" href="javascript:void(0)"><span class="theme-icon theme-icon-x"></span></a>
    <section class="widget" id="responsive-menu-widget">
    <?php barebones_navigation('primary', 'responsive-menu', 'responsive-menu', 'responsive-menu-container'); ?>
    </section>
    <?php
    if (!is_active_sidebar('sidebar-1')) {
        return;
    }
    ?>    
    <aside id="secondary-responsive" class="widget-area" role="complementary">
        <?php
            dynamic_sidebar('sidebar-1');
        ?>
    </aside>
</div>