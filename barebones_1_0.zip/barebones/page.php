<?php
/**
 * The main template file
 *
 */
get_header();
?>
<section id="primary" class="content-area clearfix">
    <main id="main" class="site-main">
        <?php
            if(have_posts()) {
                while (have_posts()) {
                    the_post();
                    get_template_part('template-parts/page/content', 'page');
                    if ( comments_open() || get_comments_number() ) {
						comments_template();
					}
                }
                //barebones_post_pagination();
            }
        ?>
    </main>
    <?php get_sidebar(); ?>
</section>
<?php
get_footer();
?>