<?php
/**
 * Theme functions
 */

/**
 * Theme only works in WordPress 4.7 or later.
 */
if(version_compare($GLOBALS['wp_version'], '4.7', '<')) {
	require get_template_directory().'/inc/back-compat.php';
	return;
}

if(!function_exists('barebones_setup')):
/**
 * Sets up theme
 */
function barebones_setup() {
    // Translations can be filed in the /languages/ directory
    load_theme_textdomain('barebones', get_template_directory() . '/languages');
    
    // Add default posts and comments RSS feed links to head.
	add_theme_support('automatic-feed-links');
    
    // Let WordPress manage the document title
    add_theme_support('title-tag');
    
    // Enable support for Post Thumbnails on posts and pages
    add_theme_support('post-thumbnails');
    set_post_thumbnail_size( 2000, 9999 );
    
    // This theme uses wp_nav_menu().
    register_nav_menus(array('primary' => __('Primary', 'barebones')));
    
    // Switch default core markup for search form, comment form, and comments to output valid HTML5
    add_theme_support(
        'html5',
        array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
        )
    );
    
    // Add support for core custom logo
    add_theme_support(
        'custom-logo',
        array(
            'height'      => 96,
            'width'       => 96,
            'flex-width'  => false,
            'flex-height' => false,
      )
    );
	
	// Add support for custom background
	add_theme_support('custom-background');
    
    // Add theme support for selective refresh for widgets.
	add_theme_support('customize-selective-refresh-widgets');
    
    // Add support for Block Styles.
	add_theme_support('wp-block-styles');
    
    // Add support for full and wide align images.
	add_theme_support('align-wide');
    
    // Add support for editor styles.
	add_theme_support('editor-styles');
    
    // Enqueue editor styles.
	// add_editor_style('style-editor.css');
    
    // Add support for responsive embedded content.
	add_theme_support('responsive-embeds');
}
endif;
add_action('after_setup_theme', 'barebones_setup');

/**
 * Register widget area.
 */
function barebones_widgets_init() {
	register_sidebar(
		array(
			'name'          => __('Primary Sidebar', 'barebones'),
			'id'            => 'sidebar-1',
			'description'   => __('Add widgets here to appear in your footer.', 'barebones'),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action('widgets_init', 'barebones_widgets_init');

/**
 * Make Widget title SEO friendly
 */
function barebones_filter_widget_title_tag($params) {
    $params[0]['before_title'] = '<h5 class="widget-title widgettitle">';
    $params[0]['after_title']  = '</h5>' ;
    return $params;
}
add_filter('dynamic_sidebar_params' , 'barebones_filter_widget_title_tag');

/**
 * Add additional CSS classes to body_class
 */
function barebones_body_class($classes) {
	if(!is_active_sidebar('sidebar-1')) {
		array_push($classes, 'no-sidebar');
	}
	return $classes;
}
add_filter('body_class', 'barebones_body_class');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width Content width.
 */
function barebones_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters('barebones_content_width', 640);
}
add_action('after_setup_theme', 'barebones_content_width', 0);

/**
 * Enqueue scripts and styles.
 */
function barebones_scripts() {
    wp_enqueue_style('barebones-normalize', get_template_directory_uri().'/css/normalize.css', array(), '1.0');
	wp_enqueue_style('barebones-icons', get_template_directory_uri().'/icons/icons.css', array(), '1.0');
	wp_enqueue_style('barebones-style', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'));   
    wp_enqueue_script('barebones-global', get_template_directory_uri().'/js/global.js', array('jquery'), wp_get_theme()->get('Version'), true);

	if(is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
	}
}
add_action('wp_enqueue_scripts', 'barebones_scripts');

/**
 * Handles JavaScript detection.
 *
 * Adds a `js` class to the root `<html>` element when JavaScript is detected.
 */
function barebones_javascript_detection() {
	echo "<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>\n";
}
add_action('wp_head', 'barebones_javascript_detection', 0);

/**
 * Add a pingback url auto-discovery header for singularly identifiable articles.
 */
function barebones_pingback_header() {
	if (is_singular() && pings_open()) {
		printf('<link rel="pingback" href="%s">' . "\n", get_bloginfo('pingback_url'));
	}
}
add_action('wp_head', 'barebones_pingback_header');

/**
 * Replaces "[...]" (appended to automatically generated excerpts) with ... and
 * a 'Continue reading' link.
 *
 * @param string $link Link to single post/page.
 * @return string 'Continue reading' link prepended with an ellipsis.
 */
function barebones_excerpt_more($link) {
	if (is_admin()) {
		return $link;
	}

	$link = sprintf('<p class="link-more"><a href="%1$s" class="more-link">%2$s</a></p>',
		esc_url(get_permalink(get_the_ID())),
		__('More info', 'barebones')
	);
	return ' &hellip; ' . $link;
}
add_filter('excerpt_more', 'barebones_excerpt_more');

if (! function_exists('barebones_posted_on')) :
	/**
	 * Prints HTML with meta information for the current post-date/time.
	 */
	function barebones_posted_on() {
		$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time>';
		if (get_the_time('U') !== get_the_modified_time('U')) {
			$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s"><span class="screen-reader-text"> %4$s </span>%5$s</time>';
		}

		$time_string = sprintf(
			$time_string,
			esc_attr(get_the_date(DATE_W3C)),
			esc_html(get_the_date()),
			esc_attr(get_the_modified_date(DATE_W3C)),
			__('and updated on','barebones'),
			esc_html(get_the_modified_date())
		);

		printf(
			'<span class="posted-on"><span class="screen-reader-text">%1$s </span><a href="%2$s" rel="bookmark">%3$s</a></span>',
			__('Posted on','barebones'),
			esc_url(get_permalink()),
			$time_string
		);
	}
endif;

if (! function_exists('barebones_posted_by')) :
	/**
	 * Prints HTML with meta information about theme author.
	 */
	function barebones_posted_by() {
		printf(
			/* translators: 1: label. 2: post author, only visible to screen readers. 3: author link. */
			'<span class="byline"><span class="screen-reader-text">%1$s </span><span class="author vcard"><a class="url fn n" href="%2$s">%3$s</a></span></span>',
			__('by', 'barebones'),
			esc_url(get_author_posts_url(get_the_author_meta('ID'))),
			esc_html(get_the_author())
		);
	}
endif;

if (! function_exists('barebones_comment_link')) :
function barebones_comment_link() {	
	if(comments_open() && post_type_supports(get_post_type(), 'comments') && get_comments_number() > 0):
	echo '<span class="entry-comment-link">';
    comments_popup_link('', '1'.' '.__('Comment','barebones'), '%'.' '.__('Comments','barebones'), 'comments-link', '');
	echo '</span>';
    endif;	
}
endif;

/**
 * Display post thumbnail
 */
function barebones_post_thumbnail($size = "") {
    if(is_singular() && has_post_thumbnail()):
    ?>
    <div class="post-thumbnail">
        <?php the_post_thumbnail($size); ?>
    </div>
    <?php
    elseif(has_post_thumbnail()):
    ?>
    <div class="post-thumbnail">
        <a class="post-thumbnail-inner" href="<?php the_permalink(); ?>" tabindex="-1">
            <?php the_post_thumbnail($size); ?>
        </a>
    </div>
    <?php
    endif;
}

/**
 * Display Custom Logo
 */
function barebones_custom_logo($before = '', $after = '') {
	if(has_custom_logo()):
	echo $before;
	the_custom_logo();
	echo $after;
	endif;
}

/**
 * Display site nav
 */
function barebones_navigation($location, $id, $class, $container_class, $depth = 3) {
    wp_nav_menu(array(
        'theme_location' => $location,
        'menu_id' => $id,
        'menu_class' => $class,
        'container_class' => $container_class,
        'depth' => $depth
    ));
}

/**
 * Post Pagination
 */
function barebones_post_pagination() {
	// Previous/next page navigation.
	the_posts_pagination(array(
		'prev_text'          => __('Previous page', 'barebones'),
		'next_text'          => __('Next page', 'barebones'),
		'before_page_number' => '<span class="meta-nav screen-reader-text">' . __('Page', 'barebones') . ' </span>',
	));
}

/**
 * Post Navigation
 */
function barebones_post_navigation() {
	the_post_navigation(
		array(
			'next_text' => '<span class="meta-nav" aria-hidden="true">' . __('Next Post', 'barebones') . '</span> ' .
				'<span class="screen-reader-text">' . __('Next post:', 'barebones') . '</span> <br/>' .
				'<span class="post-title">%title</span>',
			'prev_text' => '<span class="meta-nav" aria-hidden="true">' . __('Previous Post', 'barebones') . '</span> ' .
				'<span class="screen-reader-text">' . __('Previous post:', 'barebones') . '</span> <br/>' .
				'<span class="post-title">%title</span>',
		)
	);
}

/**
 * Display Categories
 */
function barebones_category_list() {
    /* translators: used between list items, there is a space after the comma. */
    $categories_list = get_the_category_list(__(', ', 'barebones'));
    if ($categories_list) {
        printf(
            /* translators: 1: posted in label, only visible to screen readers. 2: list of categories. */
            '<span class="cat-links"><span class="screen-reader-text">%1$s</span>%2$s</span>',
            __('Posted in', 'barebones'),
            $categories_list
    ); // WPCS: XSS OK.
    }
}

/**
 * Display Tags
 */
function barebones_tags_list() {
	$tags_list = get_the_tag_list('#', __(', #', 'barebones'));
	if ($tags_list) {
		printf(
			/* translators: 1: posted in label, only visible to screen readers. 2: list of tags. */
			'<span class="tags-links"><span class="screen-reader-text">%1$s </span>%2$s</span>',
			__('Tags:', 'barebones'),
			$tags_list
		); // WPCS: XSS OK.
	}
}

/**
 * Display author bio
 */
function barebones_author_bio() {
	if (is_singular() && get_the_author_meta('description') && is_multi_author()) :
	?>
	<div class="author-info">
		<div class="author-avatar">
			<?php
				$author_bio_avatar_size = apply_filters('barebones_author_bio_avatar_size', 64);
				echo get_avatar(get_the_author_meta('user_email'), $author_bio_avatar_size);
			?>
		</div>
		<div class="author-description">
			<h6 class="author-desc-title"><?php echo get_the_author(); ?></h6>
			<p><?php the_author_meta('description'); ?></p>
			<p><a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>" rel="author"><?php printf(__('View all posts by %s', 'barebones'), get_the_author()); ?></a></p>
		</div>
	</div>
	<?php
	endif;
}

/**
 * Add odd/even class to post
 */
global $current_class;
$current_class = 'odd';
function barebones_oddeven_post_class($classes) {
	global $current_class;
	$classes[] = $current_class;
	$current_class = ($current_class == 'odd') ? 'even' : 'odd';
	return $classes;
}
add_filter ('post_class' , 'barebones_oddeven_post_class');

/**
 * Get unique ID.
 *
 */
function barebones_unique_id($prefix = '') {
	static $id_counter = 0;
	if (function_exists('wp_unique_id')) {
		return wp_unique_id($prefix);
	}
	return $prefix . (string) ++$id_counter;
}

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';
?>