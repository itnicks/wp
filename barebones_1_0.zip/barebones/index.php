<?php
/**
 * The main template file
 *
 */
get_header();
?>
<section id="primary" class="content-area clearfix">
    <main id="main" class="site-main">
        <?php
            if(have_posts()) {
                while (have_posts()) {
                    the_post();
                    get_template_part('template-parts/post/content');
                }
                barebones_post_pagination();
            }
        ?>
    </main>
    <?php get_sidebar(); ?>
</section>
<?php
get_footer();
?>