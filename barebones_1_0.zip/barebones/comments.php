<?php
/**
 * The template for displaying comments
 */
if (post_password_required()) {
	return;
}
?>
<div id="comments" class="<?php echo comments_open() ? 'comments-area' : 'comments-area comments-closed'; ?>">
    <?php
    //Show comment form on top if order of comments is newest on top
    if ( comments_open() && 'desc' === strtolower( get_option( 'comment_order', 'asc' ) ) ) :
    ?>
    
    <?php
    comment_form(array(
		'title_reply_before' => '<h5 class="reply-title">',
		'title_reply_after' => '</h5>',
		'title_reply' => __('Leave a comment','barebones')
	));
    endif;
    ?>
    
    <?php if (have_comments()) : ?>
    <h5 class="comments-title">
    <?php
    $comments_number = get_comments_number();
    if ('1' === $comments_number) {
        /* translators: %s: post title */
        printf(_x('One comment to &ldquo;%s&rdquo;', 'comments title', 'barebones'), get_the_title());
    } else {
        printf(
            /* translators: 1: number of comments, 2: post title */
            _nx(
                '%1$s comment to &ldquo;%2$s&rdquo;',
                '%1$s comments to &ldquo;%2$s&rdquo;',
                $comments_number,
                'comments title',
                'barebones'
           ),
            number_format_i18n($comments_number),
            get_the_title()
       );
    }
    ?>
    </h5>
	<?php
	the_comments_navigation();
	?>
	<div class="comments-list">
		<?php
			wp_list_comments(
				array(
					'avatar_size' => 64,
					'style'       => 'div',
					'short_ping'  => true,
					'reply_text'  => __('Reply', 'barebones'),
				)
			);
		?>
	</div>
    <?php endif; ?>
    
    <?php
    //Show comment form in bottom if order of comments is oldest on top
    if ( comments_open() && 'asc' === strtolower( get_option( 'comment_order', 'asc' ) ) ) :
    ?>
    <?php
    comment_form(array(
		'title_reply_before' => '<h5 class="reply-title">',
		'title_reply_after' => '</h5>',
		'title_reply' => __('Leave a comment','barebones')
	));
    endif;
    ?>
</div>