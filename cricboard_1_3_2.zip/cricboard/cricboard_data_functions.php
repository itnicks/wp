<?php
/**
 * Cricboard Data Functions
 */

//Convert array list to array key/value
function cricboard_to_kv_list($input) {
  $output = array();
  foreach($input as $list_entry) {
    $output[$list_entry] = $list_entry;
  }
  return $output;
}

//Convert array list to array key/value
function cricboard_to_label_val_arr($input) {
  $output = array();
  foreach($input as $list_entry) {
    $new_entry = array('key' => $list_entry, 'value' => $list_entry);
    array_push($output, $new_entry);
  }
  return $output;
}

//Get All Users
function cricboard_users($exclude = null) {
  $output = array();
  if($exclude != null) $args = array('exclude' => $exclude, 'orderby' => 'display_name');
  else $args = array('orderby' => 'display_name');
  foreach(get_users($args) as $entry) {
      $user_meta = get_userdata($entry->ID);
      if(trim($user_meta->roles[0]) != '')
      array_push($output, array('ID' => $entry->ID, 'display_name' => $entry->display_name));
  }
  return $output;
}

function cricboard_dropdown_list($list, $value, $label) {
  $return_list = array();
  foreach($list as $entry) {
      array_push($return_list, array('value' => $entry[$value], 'label' => $entry[$label]));
  }
  return $return_list;
}

//Get user display name
function cricboard_user_display_name($id) {
  $user_info = get_userdata($id);
  return $user_info->display_name;
}

//Convert date to readable format
function cricboard_format_date($date_str) {
    return date('jS F Y h:i A', strtotime($date_str));
}

//Get total number of games played by User
function cricboard_total_matches($user_id, $league_id = null, $opponent_id = null) {
    $wins = count(cricboard_win_matches($user_id, $league_id, $opponent_id));
    $losses = count(cricboard_lost_matches($user_id, $league_id, $opponent_id));
    $total_games = $wins + $losses;
    return $total_games;
}

//Get league names
function cricboard_get_leagues() {
    $leagues = get_posts(array('post_type' => 'league','posts_per_page'   => -1));
    $output = array();
    foreach ($leagues as $entry) {
        array_push($output, array('ID' => $entry->ID, 'post_title' => $entry->post_title));
    }
    return $output;
}

//Get all matches
function cricboard_all_matches($league_id = null, $limit = null) {
    if($league_id != null && $limit != null) {
        $args = array('post_type' => 'league', 'post_id' => $league_id, 'orderby' => 'comment_ID', 'number' => $limit);
    } elseif($league_id != null) {
        $args = array('post_type' => 'league', 'post_id' => $league_id, 'orderby' => 'comment_ID');
    } elseif($limit != null) {
        $args = array('post_type' => 'league', 'number' => $limit, 'orderby' => 'comment_ID');
    } else {
        $args = array('post_type' => 'league', 'orderby' => 'comment_ID');
    }
    return get_comments($args);
}

//Get win matches results
function cricboard_win_matches($user_id, $league_id = null, $opponent_id = null) {
    if($league_id != null && $opponent_id != null) {
        $args = array('post_type' => 'league', 'post_id'=>$league_id, 'meta_key'=>'opponent', 'meta_value'=>$opponent_id, 'author__in'=> $user_id);
    } elseif($league_id != null) {
        $args = array('post_type' => 'league', 'author__in'=> $user_id, 'post_id'=>$league_id);
    } elseif($opponent_id != null) {
        $args = array('post_type' => 'league', 'author__in'=> $user_id, 'meta_key'=>'opponent', 'meta_value'=>$opponent_id);
    } else {
        $args = array('post_type' => 'league', 'author__in'=> $user_id);
    }
    return get_comments($args);
}

//Get lost matches results
function cricboard_lost_matches($user_id, $league_id = null, $opponent_id = null) {
    if($league_id != null && $opponent_id != null) {
        $args = array('post_type' => 'league', 'post_id'=>$league_id, 'meta_key'=>'opponent', 'meta_value'=>$user_id, 'author__in'=> $opponent_id);
    } elseif($league_id != null) {
        $args = array('post_type' => 'league', 'post_id'=>$league_id, 'meta_key'=>'opponent', 'meta_value'=>$user_id);
    } elseif($opponent_id != null) {
        $args = array('post_type' => 'league', 'meta_key'=>'opponent', 'meta_value'=>$user_id, 'author__in'=> $opponent_id);
    } else {
        $args = array('post_type' => 'league', 'meta_key'=>'opponent', 'meta_value'=>$user_id);
    }
    return get_comments($args);
}

//Get bid won counts for winner
function cricboard_bids_won_by_winner($user_id, $league_id = null) {
    $won_matches = cricboard_win_matches($user_id, $league_id);
    $bid_count = 0;
    foreach($won_matches as $entry) {
      $bid_result = get_comment_meta($entry->comment_ID, 'bid_result', true);
      if($bid_result == "won") $bid_count++;
    }
    return $bid_count;
}

//Get bid won count for loser
function cricboard_bids_won_by_loser($user_id, $league_id = null) {
    $lost_matches = cricboard_lost_matches($user_id, $league_id);
    $bid_count = 0;
    foreach($lost_matches as $entry) {
      $bid_result = get_comment_meta($entry->comment_ID, 'bid_result', true);
      if($bid_result == "lost") $bid_count++;
    }
    return $bid_count;
}

//Get last 5 matches record
function cricboard_last_games($player_id, $post_id) {
    $data = array();
    $wins = cricboard_win_matches($player_id, $post_id);
    $loss = cricboard_lost_matches($player_id, $post_id);
    
    foreach($wins as $entry) {
        array_push ($data, array(
            'result' => __('Won', 'cricboard'),
            'posted' => cricboard_format_date($entry->comment_date),
            'comment_id' => $entry->comment_ID,
        ));
    }
    
    foreach($loss as $entry) {
        array_push ($data, array(
            'result' => __('Lost', 'cricboard'),
            'posted' => cricboard_format_date($entry->comment_date),
            'comment_id' => $entry->comment_ID,
        ));
    }
    
    $output = '';
    if(count($data) > 0) {
        $sorted_data = cricboard_sort_list($data, 'comment_id');
        $count = 0;
        foreach($sorted_data as $entry) {
            if($count >= 5) break;
            if($entry['result'] == 'Won')
              $output .= '<span class="win_flg">W</span>';
            else
              $output .= '<span class="lose_flg">L</span>';
            $count++;            
        }
    }
    
    return $output;
}

//Get league's overall leaderboard
/*
function cricboard_league_leaderboard() {
    global $wpdb;
    $users = get_users();
    $post_id = get_the_ID();
    $win_points = intval(get_post_meta($post_id, 'win_points', true));
    $part_points = intval(get_post_meta($post_id, 'part_points', true));
    $bid_points = intval(get_post_meta($post_id, 'bid_points', true));
    $data = array();
    $column_list = array(
        'player'=>array('key'=>'player', 'value'=> '<span class="full-label">'.__('Player', 'cricboard').'</span><span class="short-label">P</span>'),
        'matches'=>array('key'=>'matches', 'value'=> '<span class="full-label">'.__('Matches Played', 'cricboard').'</span><span class="short-label">M</span>'),
        'wins'=>array('key'=>'wins', 'value'=> '<span class="full-label">'.__('Won', 'cricboard').'</span><span class="short-label">W</span>'),
        'loss'=>array('key'=>'loss', 'value'=> '<span class="full-label">'.__('Lost', 'cricboard').'</span><span class="short-label">L</span>'),
        'points'=>array('key'=>'points', 'value'=> '<span class="full-label">'.__('Points', 'cricboard').'</span><span class="short-label">Pts</span>'),
        'percent'=>array('key'=>'percent', 'value'=> '<span class="full-label">'.__('Win Percent (%)', 'cricboard').'</span><span class="short-label">%</span>'),
        'last_games'=>array('key'=>'last_games', 'value'=> '<span class="full-label">'.__('Last 5 Games', 'cricboard').'</span><span class="short-label">Rec</span>'),
    );
    $team_column_list = array(
        'team'=>array('key'=>'team', 'value'=>__('Team', 'cricboard')),
        'matches'=>array('key'=>'matches', 'value'=>'<span class="full-label">'.__('Matches Played', 'cricboard').'</span><span class="short-label">M</span>'),
        'wins'=>array('key'=>'wins', 'value'=>'<span class="full-label">'.__('Won', 'cricboard').'</span><span class="short-label">W</span>'),
        'loss'=>array('key'=>'loss', 'value'=>'<span class="full-label">'.__('Lost', 'cricboard').'</span><span class="short-label">L</span>'),
        'points'=>array('key'=>'points', 'value'=>'<span class="full-label">'.__('Points', 'cricboard').'</span><span class="short-label">Pts</span>'),
        'percent'=>array('key'=>'percent', 'value'=>'<span class="full-label">'.__('Win Percent (%)', 'cricboard').'</span><span class="short-label">%</span>'),
    );
    $team_indv_column_list = array(
        'player'=>array('key'=>'player', 'value'=> '<span class="full-label">'.__('Player', 'cricboard').'</span><span class="short-label">P</span>'),
        'matches'=>array('key'=>'matches', 'value'=> '<span class="full-label">'.__('Matches Played', 'cricboard').'</span><span class="short-label">M</span>'),
        'wins'=>array('key'=>'wins', 'value'=> '<span class="full-label">'.__('Won', 'cricboard').'</span><span class="short-label">W</span>'),
        'loss'=>array('key'=>'loss', 'value'=> '<span class="full-label">'.__('Lost', 'cricboard').'</span><span class="short-label">L</span>'),
        'last_games'=>array('key'=>'last_games', 'value'=> '<span class="full-label">'.__('Last 5 Games', 'cricboard').'</span><span class="short-label">Rec</span>'),
    );    
    
    //$wpdb->get_var("SELECT ID FROM wp_posts WHERE post_name = 'hello-world'");
    
    foreach($users as $user_entry) {
        $player_name = $user_entry->display_name;
        $player_id = $user_entry->ID;
        
        $wins = count(cricboard_win_matches($player_id, $post_id));
        $loss = count(cricboard_lost_matches($player_id, $post_id));
        
        $total_matches = $wins + $loss;
        $winner_bid_matches = cricboard_bids_won_by_winner($player_id, $post_id);
        $loser_bid_matches = cricboard_bids_won_by_loser($player_id, $post_id);
        
        $points = ($wins * $win_points) + ($total_matches * $part_points) + ($winner_bid_matches * $bid_points) + ($loser_bid_matches * $bid_points);
        if($total_matches == 0) $win_percent = 0;
        else $win_percent = round(floatval(($wins / $total_matches) * 100), 2);
        $last_games = cricboard_last_games($player_id, $post_id);
        
        if($total_matches > 0) {
            if(!has_tag('teams', $post_id)) {
              array_push($data, array(
                  'player' => $player_name,
                  'matches' => $total_matches,
                  'wins' => $wins,
                  'loss' => $loss,
                  'points' => $points,
                  'percent' => $win_percent,
                  'last_games' => $last_games
              ));
            } else {
              array_push($data, array(
                  'player' => $player_name,
                  'matches' => $total_matches,
                  'wins' => $wins,
                  'loss' => $loss,
                  'last_games' => $last_games
              ));
            }            
        }
    }
	if(count($data) > 0) {
      if(has_tag('teams', $post_id))
        $sorted_data = cricboard_sort_list($data, 'wins');
      else $sorted_data = cricboard_sort_list($data, 'percent', 'points');
	} else $sorted_data = array();
  
  $points_text = '<p><i>'.__('Win Points:', 'cricboard').' '.get_post_meta($post_id, 'win_points', true).', '.__('Participation Points:','cricboard').' '.get_post_meta($post_id, 'part_points', true).', '.__('Bid Points:','cricboard').' '.get_post_meta($post_id, 'bid_points', true).'</i></p>';
  
  if(has_tag('teams', $post_id)) {      
    $tag_lb = cricboard_html_leaderboard(cricboard_team_leaderboard_data(), $team_column_list, 'league-team-leaderboard').cricboard_html_leaderboard($sorted_data, $team_indv_column_list, 'league-leaderboard');
  } else $tag_lb = cricboard_html_leaderboard($sorted_data, $column_list, 'league-leaderboard');
  $output = $points_text.$tag_lb;
  return $output;
}
*/

function cricboard_league_leaderboard() {
  global $wpdb;
  $post_id = get_the_ID();
  $win_points = intval(get_post_meta($post_id, 'win_points', true));
  $part_points = intval(get_post_meta($post_id, 'part_points', true));
  $bid_points = intval(get_post_meta($post_id, 'bid_points', true));
  $data = array();
  $team_data = array();
  
  $column_list = array(
    'player'=>array('key'=>'player', 'value'=> '<span class="full-label">'.__('Player', 'cricboard').'</span><span class="short-label">P</span>'),
    'matches'=>array('key'=>'matches', 'value'=> '<span class="full-label">'.__('Matches Played', 'cricboard').'</span><span class="short-label">M</span>'),
    'wins'=>array('key'=>'wins', 'value'=> '<span class="full-label">'.__('Won', 'cricboard').'</span><span class="short-label">W</span>'),
    'loss'=>array('key'=>'loss', 'value'=> '<span class="full-label">'.__('Lost', 'cricboard').'</span><span class="short-label">L</span>'),
    'points'=>array('key'=>'points', 'value'=> '<span class="full-label">'.__('Points', 'cricboard').'</span><span class="short-label">Pts</span>'),
    'percent'=>array('key'=>'percent', 'value'=> '<span class="full-label">'.__('Win Percent (%)', 'cricboard').'</span><span class="short-label">%</span>'),
    'last_games'=>array('key'=>'last_games', 'value'=> '<span class="full-label">'.__('Last 5 Games', 'cricboard').'</span><span class="short-label">Rec</span>'),
  );
  
  $team_column_list = array(
      'team'=>array('key'=>'team', 'value'=>__('Team', 'cricboard')),
      'matches'=>array('key'=>'matches', 'value'=>'<span class="full-label">'.__('Matches Played', 'cricboard').'</span><span class="short-label">M</span>'),
      'wins'=>array('key'=>'wins', 'value'=>'<span class="full-label">'.__('Won', 'cricboard').'</span><span class="short-label">W</span>'),
      'loss'=>array('key'=>'loss', 'value'=>'<span class="full-label">'.__('Lost', 'cricboard').'</span><span class="short-label">L</span>'),
      'points'=>array('key'=>'points', 'value'=>'<span class="full-label">'.__('Points', 'cricboard').'</span><span class="short-label">Pts</span>'),
      'percent'=>array('key'=>'percent', 'value'=>'<span class="full-label">'.__('Win Percent (%)', 'cricboard').'</span><span class="short-label">%</span>'),
  );
  
  $sql = "select ID, display_name, matches, wins, losses, points, win_percent from (
          select ID, display_name, matches, wins, losses, ((wins * ".$win_points.") + (matches * ".$part_points.")) as points, if(matches < 1, 0, round((wins/matches)*100, 2)) as win_percent
          from (
          select u.ID, u.display_name, (ifnull(w.wins, 0) + ifnull(l.losses, 0)) as matches, ifnull(w.wins, 0) as wins, ifnull(l.losses, 0) as losses from wp_users u
          left outer join
          (select u.ID, count(*) as wins from wp_comments c, wp_users u where c.user_id = u.ID and c.comment_approved = 1 and c.comment_post_ID = ".$post_id." group by u.ID) w on u.ID = w.ID
          left OUTER JOIN
          (select u.ID, count(*) as losses from wp_comments c, wp_commentmeta cm, wp_users u where cm.meta_key = 'opponent' and cm.meta_value = u.ID and c.comment_approved = 1 and cm.comment_id = c.comment_ID and c.comment_post_ID = ".$post_id." group by u.ID) l on u.ID = l.ID
          ) m
          ) p order by points desc, win_percent desc";

  $lb_result = $wpdb->get_results($sql);
  
  foreach($lb_result as $lb_entry) {
    if($lb_entry->matches > 0):
    $last_games = cricboard_last_games($lb_entry->ID, $post_id);    
    array_push($data, array(
        'player' => $lb_entry->display_name,
        'matches' => $lb_entry->matches,
        'wins' => $lb_entry->wins,
        'loss' => $lb_entry->losses,
        'points' => $lb_entry->points,
        'percent' => $lb_entry->win_percent,
        'last_games' => $last_games
    ));
    endif;
  }
  
  if(has_tag('teams', $post_id)) {
      $tsql = "select * from (select player, matches, wins, losses, ((wins * ".$win_points.") + (matches * ".$part_points.")) as points, if(matches < 1, 0, round((wins/matches)*100, 2)) as win_percent from (
      select distinct player, (wins + losses) as matches, wins, losses from (
      select ifnull(w.meta_value, l.meta_value) as player, ifnull(w.wins, 0) as wins, ifnull(l.losses, 0) as losses from wp_postmeta pm
      left outer join
      (
      select pm.meta_value, count(*) as wins from wp_comments c, wp_users u, wp_postmeta pm where c.user_id = u.ID and c.comment_post_ID = pm.post_id and replace(pm.meta_key, 'team_', '') = u.ID and c.comment_approved = 1 and c.comment_post_ID = ".$post_id." group by pm.meta_value
      ) w on w.meta_value = pm.meta_value
      left outer join
      (
      select pm.meta_value, count(*) as losses from wp_comments c, wp_commentmeta cm, wp_users u, wp_postmeta pm where cm.meta_key = 'opponent' and cm.meta_value = u.ID and cm.comment_id = c.comment_ID and c.comment_approved = 1 and c.comment_post_ID = pm.post_id and replace(pm.meta_key, 'team_', '') = u.ID and c.comment_post_ID = ".$post_id." group by pm.meta_value
      ) l on l.meta_value = pm.meta_value
      where pm.meta_key like 'team_%' and pm.post_ID = ".$post_id."
      ) t where t.player is not null
      ) lb) f order by points desc, win_percent desc";
      
      $tlb_result = $wpdb->get_results($tsql);
      
      foreach($tlb_result as $lb_entry) {
        if($lb_entry->matches > 0):  
        array_push($team_data, array(
            'team' => $lb_entry->player,
            'matches' => $lb_entry->matches,
            'wins' => $lb_entry->wins,
            'loss' => $lb_entry->losses,
            'points' => $lb_entry->points,
            'percent' => $lb_entry->win_percent
        ));
        endif;
      }
      
  }
  
  $output = '';
  if(count($data) > 0) {
    $points_text = '<p><i>'.__('Win Points:', 'cricboard').' '.get_post_meta($post_id, 'win_points', true).', '.__('Participation Points:','cricboard').' '.get_post_meta($post_id, 'part_points', true).', '.__('Bid Points:','cricboard').' '.get_post_meta($post_id, 'bid_points', true).'</i></p>';
    
    if(has_tag('teams', $post_id)) {
      $output .= $points_text.cricboard_html_leaderboard($team_data, $team_column_list, 'league-leaderboard').cricboard_html_leaderboard($data, $column_list, 'league-leaderboard');
    } else {
      $output .= $points_text.cricboard_html_leaderboard($data, $column_list, 'league-leaderboard');  
    }    
  }
  return $output;  
}

//Get team based leaderboard
function cricboard_team_leaderboard_data() {
    $users = get_users();
    $post_id = get_the_ID();
    $win_points = intval(get_post_meta($post_id, 'win_points', true));
    $part_points = intval(get_post_meta($post_id, 'part_points', true));
    $data = array();
    $ind_data = array();
    $win_arr = array();
    $loss_arr = array();
    $match_arr = array();
    foreach($users as $user_entry) {
        $player_name = $user_entry->display_name;
        $player_id = $user_entry->ID;
        
        $wins = count(cricboard_win_matches($player_id, $post_id));
        $loss = count(cricboard_lost_matches($player_id, $post_id));
        $matches = $wins + $loss;

        $value = get_post_meta($post_id, 'team_'.$player_id, true);
        
        if(array_key_exists($value, $win_arr)) {
          $wins = $win_arr[$value] + $wins;
          $win_arr[$value] = $wins;
        } else {
          $win_arr[$value] = $wins;
        }
        
        if(array_key_exists($value, $loss_arr)) {
          $loss = $loss_arr[$value] + $loss;
          $loss_arr[$value] = $loss;
        } else {
          $loss_arr[$value] = $loss;
        }
        
        if(array_key_exists($value, $match_arr)) {
          $matches = $match_arr[$value] + $matches;
          $match_arr[$value] = $matches;
        } else {
          $match_arr[$value] = $matches;
        }
    }

    foreach(array_keys($match_arr) as $entry) {
        $points = ($win_arr[$entry] * $win_points) + ($match_arr[$entry] * $part_points);
        if($match_arr[$entry] == 0) $win_percent = 0;
        else $win_percent = round(floatval(($win_arr[$entry] / $match_arr[$entry]) * 100), 2);
        
        if(trim($entry) != '') {
          array_push($data, array(
            'team' => $entry,
            'matches' => $match_arr[$entry],
            'wins' => $win_arr[$entry],
            'loss' => $loss_arr[$entry],
            'points' => $points,
            'percent' => $win_percent
          ));
        }
    }
    
    $sorted_data = cricboard_sort_list($data, 'percent', 'points');
    
    return $sorted_data;
}


//League leading run_scorer
function cricboard_league_run_scorer() {
    $post_id = get_the_ID();
    return cricboard_leading_run_scorer($post_id);
}

function cricboard_leading_run_scorer($post_id) {
    global $wpdb;
    $data = array();
    $column_list = array(
        'player'=>array('key'=>'player', 'value'=> '<span class="full-label">'.__('Player', 'cricboard').'</span><span class="short-label">P</span>'),
        'matches'=>array('key'=>'matches', 'value'=> '<span class="full-label">'.__('Matches Played', 'cricboard').'</span><span class="short-label">M</span>'),
        'runs'=>array('key'=>'runs', 'value'=> '<span class="full-label">'.__('Runs Scored', 'cricboard').'</span><span class="short-label">RS</span>'),
        'strike_rate'=>array('key'=>'strike_rate', 'value'=> '<span class="full-label">'.__('Strike Rate', 'cricboard').'</span><span class="short-label">SR</span>'),
    );
    
    if($post_id > 0) $order_by = "strike_rate desc,"; else $order_by = "";
    
    $sql = "select player, matches, runs, strike_rate from (
            select player, matches, runs, if(overs < 1, 0, round((runs/(overs*6))*100,2) ) as strike_rate from (
            select u.display_name as player, (ifnull(w.matches,0) + ifnull(l.matches,0)) as matches, (ifnull(w.runs,0) + ifnull(l.runs,0)) as runs, (ifnull(w.overs,0) + ifnull(l.overs,0)) as overs from wp_users u
            left outer join
            (select u.id, count(c.comment_ID) as matches, sum(ifnull(r.meta_value, 0)) as runs, sum(ifnull(o.meta_value, 0)) as overs from wp_users u
            inner join wp_comments c on c.user_id = u.ID and c.comment_approved = 1 and c.comment_post_ID = if(".$post_id." = 0, c.comment_post_ID, ".$post_id.")
            left outer join wp_commentmeta r on r.comment_id = c.comment_ID and r.meta_key = 'my_runs'
            left outer join wp_commentmeta o on o.comment_id = c.comment_ID and o.meta_key = 'my_overs'
            group by u.id) w on w.id = u.id
            left outer join    
            (select u.id, count(c.comment_ID) as matches, sum(ifnull(r.meta_value, 0)) as runs, sum(ifnull(o.meta_value, 0)) as overs from wp_users u
            inner join wp_commentmeta cm on cm.meta_value = u.ID and cm.meta_key = 'opponent'
            inner join wp_comments c on c.comment_ID = cm.comment_id  and c.comment_approved = 1 and c.comment_post_ID = if(".$post_id." = 0, c.comment_post_ID, ".$post_id.")
            left outer join wp_commentmeta r on r.comment_id = cm.comment_ID and r.meta_key = 'opp_runs'
            left outer join wp_commentmeta o on o.comment_id = cm.comment_ID and o.meta_key = 'opp_overs'
            group by u.id) l on l.id = u.id
            
            ) rn where matches > 0) rb order by ".$order_by." runs desc";

    $lb_result = $wpdb->get_results($sql);
    
    foreach($lb_result as $lb_entry) { 
      array_push($data, array(
          'player' => $lb_entry->player,
          'matches' => $lb_entry->matches,
          'runs' => $lb_entry->runs,
          'strike_rate' => $lb_entry->strike_rate
      ));
    }
    
    $settings = (array) get_option('cricboard-plugin-settings');
    if($settings['stats_limit'] == "" || $settings['stats_limit'] == 0) $stats_limit = CRICBOARD_STATS_LIMIT; else $stats_limit = intval($settings['stats_limit']);
    
    $output = '';
    if(count($data) > 0) {
        $output .= cricboard_html_leaderboard($data, $column_list, 'strikerate-leaderboard', $stats_limit);
    }
    return $output;
}

//Top run scrorer leaderboard
/*
function cricboard_leading_run_scorer($post_id) {
    $users = get_users();
    //$post_id = get_the_ID();
    $data = array();
    $column_list = array(
        'player'=>array('key'=>'player', 'value'=> '<span class="full-label">'.__('Player', 'cricboard').'</span><span class="short-label">P</span>'),
        'matches'=>array('key'=>'matches', 'value'=> '<span class="full-label">'.__('Matches Played', 'cricboard').'</span><span class="short-label">M</span>'),
        'runs'=>array('key'=>'runs', 'value'=> '<span class="full-label">'.__('Runs Scored', 'cricboard').'</span><span class="short-label">RS</span>'),
        'strike_rate'=>array('key'=>'strike_rate', 'value'=> '<span class="full-label">'.__('Strike Rate', 'cricboard').'</span><span class="short-label">SR</span>'),
    );
    
    foreach($users as $user_entry) {
        $player_name = $user_entry->display_name;
        $player_id = $user_entry->ID;
        if(trim($post_id) != "" && $post_id != '0') {
          $wins = cricboard_win_matches($player_id, $post_id);
          $loss = cricboard_lost_matches($player_id, $post_id);
        } else {
          $wins = cricboard_win_matches($player_id);
          $loss = cricboard_lost_matches($player_id);
        }
        $total_matches = count($wins) + count($loss);
        $total_runs = 0;
        $total_overs = 0;
        foreach($wins as $run_entry) {
            $run = intval(get_comment_meta($run_entry->comment_ID, 'my_runs', true));
            $overs = intval(get_comment_meta($run_entry->comment_ID, 'my_overs', true));
            $total_runs = $total_runs + $run;
            $total_overs = $total_overs + $overs;
        }        
        foreach($loss as $run_entry) {
            $run = intval(get_comment_meta($run_entry->comment_ID, 'opp_runs', true));
            $overs = intval(get_comment_meta($run_entry->comment_ID, 'opp_overs', true));
            $total_runs = $total_runs + $run;
            $total_overs = $total_overs + $overs;
        }
        if(isset($total_overs) && $total_overs > 0) $strike_rate = (($total_runs / ($total_overs * 6)) * 100); else $strike_rate = 0;
        if($total_matches > 0) {
            array_push($data, array(
                'player' => $player_name,
                'matches' => $total_matches,
                'runs' => $total_runs,
                'strike_rate' => round($strike_rate, 2)
            ));
        }
    }
	
  $settings = (array) get_option('cricboard-plugin-settings');
  if($settings['stats_limit'] == "" || $settings['stats_limit'] == 0) $stats_limit = CRICBOARD_STATS_LIMIT; else $stats_limit = intval($settings['stats_limit']);
	
	if(count($data) > 0) {
    $sorted_data = cricboard_sort_list($data, 'runs');
    $sorted_data_strike = cricboard_sort_list($data, 'strike_rate');
	} else { $sorted_data = array(); $sorted_data_strike = array(); }
    
    $output = '<h5>'.__('Leading Run Scorers','cricboard').'</h5>'.cricboard_html_leaderboard($sorted_data, $column_list, 'runs-leaderboard', $stats_limit);
    $output .= '<h5>'.__('Leading Strike Rates','cricboard').'</h5>'.cricboard_html_leaderboard($sorted_data_strike, $column_list, 'strikerate-leaderboard', $stats_limit);
    return $output;
}
*/

//Top league wicket taker
function cricboard_league_wicket_takers() {
  $post_id = get_the_ID();
  return cricboard_leading_wicket_takers($post_id);
}

function cricboard_leading_wicket_takers($post_id) {
  global $wpdb;
  $data = array();
  $column_list = array(
      'player'=>array('key'=>'player', 'value'=> '<span class="full-label">'.__('Player', 'cricboard').'</span><span class="short-label">P</span>'),
      'matches'=>array('key'=>'matches', 'value'=> '<span class="full-label">'.__('Matches Played', 'cricboard').'</span><span class="short-label">M</span>'),
      'wickets'=>array('key'=>'wickets', 'value'=> '<span class="full-label">'.__('Wickets Taken', 'cricboard').'</span><span class="short-label">WK</span>'),
      'overs_bowled'=>array('key'=>'overs_bowled', 'value'=> '<span class="full-label">'.__('Overs Bowled', 'cricboard').'</span><span class="short-label">OV</span>'),
      'economy_rate'=>array('key'=>'economy_rate', 'value'=> '<span class="full-label">'.__('Economy Rate', 'cricboard').'</span><span class="short-label">ER</span>'),
  );
  
  $sql = "select player, matches, runs_given, round(overs_bowled, 0) as overs_bowled, wickets_taken, eco_rate from (
          select player, matches, runs_given, overs_bowled, wickets_taken, if(overs_bowled < 1, 0, round((runs_given/overs_bowled),2) ) as eco_rate from (
          select u.display_name as player, (ifnull(w.matches,0) + ifnull(l.matches,0)) as matches, (ifnull(w.runs_given,0) + ifnull(l.runs_given,0)) as runs_given, (ifnull(w.overs_bowled,0) + ifnull(l.overs_bowled,0)) as overs_bowled, (ifnull(w.wickets_taken,0) + ifnull(l.wickets_taken,0)) as wickets_taken from wp_users u
          left outer join
          (select u.id, count(c.comment_ID) as matches, sum(ifnull(r.meta_value, 0)) as runs_given, sum(ifnull(o.meta_value, 0)) as overs_bowled, sum(ifnull(wk.meta_value, 0)) as wickets_taken from wp_users u
          inner join wp_comments c on c.user_id = u.ID and c.comment_approved = 1 and c.comment_post_ID = if(".$post_id." = 0, c.comment_post_ID, ".$post_id.")
          left outer join wp_commentmeta r on r.comment_id = c.comment_ID and r.meta_key = 'opp_runs'
          left outer join wp_commentmeta o on o.comment_id = c.comment_ID and o.meta_key = 'opp_overs'
          left outer join wp_commentmeta wk on wk.comment_id = c.comment_ID and wk.meta_key = 'opp_wickets'
          group by u.id) w on w.id = u.id
          left outer join    
          (select u.id, count(c.comment_ID) as matches, sum(ifnull(r.meta_value, 0)) as runs_given, sum(ifnull(o.meta_value, 0)) as overs_bowled, sum(ifnull(wk.meta_value, 0)) as wickets_taken from wp_users u
          inner join wp_commentmeta cm on cm.meta_value = u.ID and cm.meta_key = 'opponent'
          inner join wp_comments c on c.comment_ID = cm.comment_id and c.comment_approved = 1 and c.comment_post_ID = if(".$post_id." = 0, c.comment_post_ID, ".$post_id.")
          left outer join wp_commentmeta r on r.comment_id = cm.comment_ID and r.meta_key = 'my_runs'
          left outer join wp_commentmeta o on o.comment_id = cm.comment_ID and o.meta_key = 'my_overs'
          left outer join wp_commentmeta wk on wk.comment_id = cm.comment_ID and wk.meta_key = 'my_wickets'
          group by u.id) l on l.id = u.id
          
          ) rn where matches > 0) rb order by wickets_taken desc";

  $lb_result = $wpdb->get_results($sql);
  
  foreach($lb_result as $lb_entry) { 
      array_push($data, array(
          'player' => $lb_entry->player,
          'matches' => $lb_entry->matches,
          'wickets' => $lb_entry->wickets_taken,
          'overs_bowled' => $lb_entry->overs_bowled,
          'economy_rate' => $lb_entry->eco_rate
      ));
  }
  
  $settings = (array) get_option('cricboard-plugin-settings');
  if($settings['stats_limit'] == "" || $settings['stats_limit'] == 0) $stats_limit = CRICBOARD_STATS_LIMIT; else $stats_limit = intval($settings['stats_limit']);
  
  $output = '';
  if(count($data) > 0) {
      $output .= cricboard_html_leaderboard($data, $column_list, 'wickets-leaderboard', $stats_limit);
  }
  return $output;
}

//Top wicket taker leaderboard
/*
function cricboard_leading_wicket_takers($post_id) {
  $users = get_users();
  //$post_id = get_the_ID();
  $data = array();
  $column_list = array(
      'player'=>array('key'=>'player', 'value'=> '<span class="full-label">'.__('Player', 'cricboard').'</span><span class="short-label">P</span>'),
      'matches'=>array('key'=>'matches', 'value'=> '<span class="full-label">'.__('Matches Played', 'cricboard').'</span><span class="short-label">M</span>'),
      'wickets'=>array('key'=>'wickets', 'value'=> '<span class="full-label">'.__('Wickets Taken', 'cricboard').'</span><span class="short-label">WK</span>'),
      'overs_bowled'=>array('key'=>'overs_bowled', 'value'=> '<span class="full-label">'.__('Overs Bowled', 'cricboard').'</span><span class="short-label">OV</span>'),
      'economy_rate'=>array('key'=>'economy_rate', 'value'=> '<span class="full-label">'.__('Economy Rate', 'cricboard').'</span><span class="short-label">ER</span>'),
  );
  foreach($users as $user_entry) {
      $player_name = $user_entry->display_name;
      $player_id = $user_entry->ID;
      if(trim($post_id) != "" && $post_id != '0') {
          $wins = cricboard_win_matches($player_id, $post_id);
          $loss = cricboard_lost_matches($player_id, $post_id);
        } else {
          $wins = cricboard_win_matches($player_id);
          $loss = cricboard_lost_matches($player_id);
        }
      $total_matches = count($wins) + count($loss);
      $total_wickets = 0;
      $total_overs = 0;
      $total_runs = 0;
      foreach($wins as $wicket_entry) {
          $wicket = intval(get_comment_meta($wicket_entry->comment_ID, 'opp_wickets', true));
          $overs = intval(get_comment_meta($wicket_entry->comment_ID, 'opp_overs', true));
          $runs = intval(get_comment_meta($wicket_entry->comment_ID, 'opp_runs', true));
          $total_wickets = $total_wickets + $wicket;
          $total_overs = $total_overs + $overs;
          $total_runs = $total_runs + $runs;
      }        
      foreach($loss as $wicket_entry) {
          $wicket = intval(get_comment_meta($wicket_entry->comment_ID, 'my_wickets', true));
          $overs = intval(get_comment_meta($wicket_entry->comment_ID, 'my_overs', true));
          $runs = intval(get_comment_meta($wicket_entry->comment_ID, 'my_runs', true));
          $total_wickets = $total_wickets + $wicket;
          $total_overs = $total_overs + $overs;
          $total_runs = $total_runs + $runs;
      }
      if(isset($total_overs) && $total_overs > 0) $econ = round(($total_runs / $total_overs), 2); else $econ = 0;
      if($total_matches > 0) {
          array_push($data, array(
              'player' => $player_name,
              'matches' => $total_matches,
              'wickets' => $total_wickets,
              'overs_bowled' => $total_overs,
              'economy_rate' => $econ,
          ));
      }
  }
  $settings = (array) get_option('cricboard-plugin-settings');
  if($settings['stats_limit'] == "" || $settings['stats_limit'] == 0) $stats_limit = CRICBOARD_STATS_LIMIT; else $stats_limit = intval($settings['stats_limit']);
  
  if(count($data) > 0) {
    	$sorted_data = cricboard_sort_list($data, 'wickets');
	} else $sorted_data = array();
  
  $output = '<h5>'.__('Leading Wicket Takers','cricboard').'</h5>'.cricboard_html_leaderboard($sorted_data, $column_list, 'wickets-leaderboard', $stats_limit);
  return $output;
}
*/

//My Matches
function cricboard_my_matches() {
    $user_id = get_current_user_id();
    $data = array();
    $column_list = array(
        'league'=>array('key'=>'league', 'value'=> '<span class="full-label">'.__('League', 'cricboard').'</span><span class="short-label">L</span>'),
        'result'=>array('key'=>'result', 'value'=> '<span class="full-label">'.__('Result', 'cricboard').'</span><span class="short-label">R</span>'),
        'opponent'=>array('key'=>'opponent', 'value'=> '<span class="full-label">'.__('Opponent', 'cricboard').'</span><span class="short-label">V/S</span>'),
        'posted'=>array('key'=>'posted', 'value'=> '<span class="full-label">'.__('Date Posted', 'cricboard').'</span><span class="short-label">D</span>'),
        'link'=>array('key'=>'link', 'value'=> '<span class="full-label">'.__('Scorecard', 'cricboard').'</span><span class="short-label">SC</span>'),
    );
    $wins = cricboard_win_matches($user_id);
    $loss = cricboard_lost_matches($user_id);
    
    foreach($wins as $entry) {
        array_push ($data, array(
            'league' => get_the_title($entry->comment_post_ID),
            'result' => __('Won', 'cricboard'),
            'opponent' => cricboard_user_display_name(get_comment_meta($entry->comment_ID, 'opponent', true)),
            'posted' => cricboard_format_date($entry->comment_date),
            'link' => '<a href="'.get_comment_link($entry->comment_ID).'">'.__('View Scorecard','cricboard').'</a>',
            'comment_id' => $entry->comment_ID,
        ));
    }
    
    foreach($loss as $entry) {
        array_push ($data, array(
            'league' => get_the_title($entry->comment_post_ID),
            'result' => __('Lost', 'cricboard'),
            'opponent' => cricboard_user_display_name($entry->user_id),
            'posted' => cricboard_format_date($entry->comment_date),
            'link' => '<a href="'.get_comment_link($entry->comment_ID).'">'.__('View Scorecard','cricboard').'</a>',
            'comment_id' => $entry->comment_ID,
        ));
    }
    
	if(count($data) > 0) {
    	$sorted_data = cricboard_sort_list($data, 'comment_id');  
	} else $sorted_data = array();
    $filter_output = cricboard_output_field('league-filter', 'select', __('by league','cricboard'), '', cricboard_dropdown_list(cricboard_get_leagues(), 'post_title', 'post_title'), false, false);
    $filter_output .= cricboard_output_field('opponent-filter', 'select', ' '.__('by opponent','cricboard'), '', cricboard_dropdown_list(cricboard_users(get_current_user_id()), 'display_name', 'display_name'), false, false);
    $output = '<p>'.__('Filter','cricboard').' '.$filter_output.'</p>'.cricboard_html_leaderboard($sorted_data, $column_list, 'my-matches');
    return $output;
}

//Recent matches
function cricboard_recent_matches() {
    $data = array();
    $column_list = array(
        'league'=>array('key'=>'league', 'value'=> '<span class="full-label">'.__('League', 'cricboard').'</span><span class="short-label">L</span>'),
        'player'=>array('key'=>'player', 'value'=> '<span class="full-label">'.__('Player', 'cricboard').'</span><span class="short-label">Player</span>'),
        'result'=>array('key'=>'result', 'value'=> '<span class="full-label">'.__('Result', 'cricboard').'</span><span class="short-label">R</span>'),
        'opponent'=>array('key'=>'opponent', 'value'=> '<span class="full-label">'.__('Opponent', 'cricboard').'</span><span class="short-label">V/S</span>'),
        'posted'=>array('key'=>'posted', 'value'=> '<span class="full-label">'.__('Date Posted', 'cricboard').'</span><span class="short-label">D</span>'),
        'link'=>array('key'=>'link', 'value'=> '<span class="full-label">'.__('Scorecard', 'cricboard').'</span><span class="short-label">SC</span>'),
    );
    $matches = cricboard_all_matches();
    foreach($matches as $entry) {
        array_push ($data, array(
            'league' => get_the_title($entry->comment_post_ID),
            'player' => cricboard_user_display_name($entry->user_id),
            'result' => __('Won against', 'cricboard'),
            'opponent' => cricboard_user_display_name(get_comment_meta($entry->comment_ID, 'opponent', true)),
            'posted' => cricboard_format_date($entry->comment_date),
            'link' => '<a href="'.get_comment_link($entry->comment_ID).'">'.__('View Scorecard','cricboard').'</a>',
        ));
    }
    $filter_output = cricboard_output_field('league-filter', 'select', __('by league','cricboard'), '', cricboard_dropdown_list(cricboard_get_leagues(), 'post_title', 'post_title'), false, false);
    $filter_output .= cricboard_output_field('player-filter', 'select', ' '.__('by player','cricboard'), '', cricboard_dropdown_list(cricboard_users(), 'display_name', 'display_name'), false, false);
    $output = '<p>'.__('Filter','cricboard').' '.$filter_output.'</p>'.cricboard_html_leaderboard($data, $column_list, 'recent-matches');
    return $output;
}

function cricboard_overall_leaderboard() {
  global $wpdb;
    $data = array();
    $column_list = array(
        'player'=>array('key'=>'player', 'value'=> '<span class="full-label">'.__('Player', 'cricboard').'</span><span class="short-label">P</span>'),
        'matches'=>array('key'=>'matches', 'value'=> '<span class="full-label">'.__('Matches Played', 'cricboard').'</span><span class="short-label">M</span>'),
        'wins'=>array('key'=>'wins', 'value'=> '<span class="full-label">'.__('Won', 'cricboard').'</span><span class="short-label">W</span>'),
        'loss'=>array('key'=>'loss', 'value'=> '<span class="full-label">'.__('Lost', 'cricboard').'</span><span class="short-label">L</span>'),'percent'=>array('key'=>'percent', 'value'=> '<span class="full-label">'.__('Win Percent (%)', 'cricboard').'</span><span class="short-label">%</span>'),
    );
    
    $sql = "select display_name, matches, wins, losses, win_percent from (
          select display_name, matches, wins, losses, if(matches < 1, 0, round((wins/matches)*100, 2)) as win_percent
          from (
          select u.ID, u.display_name, (ifnull(w.wins, 0) + ifnull(l.losses, 0)) as matches, ifnull(w.wins, 0) as wins, ifnull(l.losses, 0) as losses from wp_users u
          left outer join
          (select u.ID, count(*) as wins from wp_comments c, wp_users u, wp_posts p where c.user_id = u.ID and c.comment_approved = 1 and c.comment_post_ID = p.ID and p.post_type = 'league' group by u.ID) w on u.ID = w.ID
          left OUTER JOIN
          (select u.ID, count(*) as losses from wp_comments c, wp_commentmeta cm, wp_users u, wp_posts p where cm.meta_key = 'opponent' and cm.meta_value = u.ID and cm.comment_id = c.comment_ID and c.comment_approved = 1 and c.comment_post_ID = p.ID and p.post_type = 'league' group by u.ID) l on u.ID = l.ID
          ) m
          ) p order by wins desc, win_percent desc";

    $lb_result = $wpdb->get_results($sql);
    
    foreach($lb_result as $lb_entry) { 
        array_push($data, array(
            'player' => $lb_entry->display_name,
            'matches' => $lb_entry->matches,
            'wins' => $lb_entry->wins,
            'loss' => $lb_entry->losses,
            'percent' => $lb_entry->win_percent
        ));
    }
    
    $output = '';
    if(count($data) > 0) {
        $output .= cricboard_html_leaderboard($data, $column_list, 'overall-leaderboard');
    }
    return $output;
}

//Overall leaderboard
/*
function cricboard_overall_leaderboard() {
    $users = get_users();
    $data = array();
    $column_list = array(
        'player'=>array('key'=>'player', 'value'=> '<span class="full-label">'.__('Player', 'cricboard').'</span><span class="short-label">P</span>'),
        'matches'=>array('key'=>'matches', 'value'=> '<span class="full-label">'.__('Matches Played', 'cricboard').'</span><span class="short-label">M</span>'),
        'wins'=>array('key'=>'wins', 'value'=> '<span class="full-label">'.__('Won', 'cricboard').'</span><span class="short-label">W</span>'),
        'loss'=>array('key'=>'loss', 'value'=> '<span class="full-label">'.__('Lost', 'cricboard').'</span><span class="short-label">L</span>'),'percent'=>array('key'=>'percent', 'value'=> '<span class="full-label">'.__('Win Percent (%)', 'cricboard').'</span><span class="short-label">%</span>'),
    );
  
    foreach($users as $user_entry) {
        $player_name = $user_entry->display_name;
        $player_id = $user_entry->ID;
        
        $wins = count(cricboard_win_matches($player_id));
        $loss = count(cricboard_lost_matches($player_id));
        
        $total_matches = $wins + $loss;
        if($total_matches == 0) $win_percent = 0;
        else $win_percent = round(floatval(($wins / $total_matches) * 100), 2);
        
        if($total_matches > 0) {
            array_push($data, array(
                'player' => $player_name,
                'matches' => $total_matches,
                'wins' => $wins,
                'loss' => $loss,
                'percent' => $win_percent
            ));           
        }
    }
    if(count($data) > 0) {
        $sorted_data = cricboard_sort_list($data, 'percent', 'wins');
    } else $sorted_data = array();    
    
    $output = cricboard_html_leaderboard($sorted_data, $column_list, 'overall-leaderboard');
    return $output;
}
*/

//Overall leading run_scorer
function cricboard_overall_run_scorer() {
    return cricboard_leading_run_scorer(0);
}

//Overall wicket taker
function cricboard_overall_wicket_takers() {
  return cricboard_leading_wicket_takers(0);
}


//Sorting function
function cricboard_sort_list($arr, $sort_key1, $sort_key2 = null, $order = 'DESC') {
    if($order == 'ASC') $sort_by = SORT_ASC; else $sort_by = SORT_DESC;
    array_multisort(array_column($arr, $sort_key1), $sort_by, $arr);
    if($sort_key2 != null) {
        array_multisort(array_column($arr, $sort_key2), $sort_by, $arr);
    }
    return $arr;
}

//Custom array_column for PHP < 5.5
if (! function_exists('array_column')) {
    function array_column(array $input, $columnKey, $indexKey = null) {
        $array = array();
        foreach ($input as $value) {
            if ( !array_key_exists($columnKey, $value)) {
                trigger_error("Key \"$columnKey\" does not exist in array");
                return false;
            }
            if (is_null($indexKey)) {
                $array[] = $value[$columnKey];
            }
            else {
                if ( !array_key_exists($indexKey, $value)) {
                    trigger_error("Key \"$indexKey\" does not exist in array");
                    return false;
                }
                if ( ! is_scalar($value[$indexKey])) {
                    trigger_error("Key \"$indexKey\" does not contain scalar value");
                    return false;
                }
                $array[$value[$indexKey]] = $value[$columnKey];
            }
        }
        return $array;
    }
}
?>