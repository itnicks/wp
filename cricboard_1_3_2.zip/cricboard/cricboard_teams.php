<?php
/**
 * Teams
 */
$tag_teams = array ('Ahmad - Krish' => array('value'=>'Ahmad - Krish'),
                    'Ahmed Iqbal - Wasim' => array('value'=>'Ahmed Iqbal - Wasim'),
                    'Ahsan - Amar' => array('value'=>'Ahsan - Amar'),
                    'Ali Zafar - Bil' => array('value'=>'Ali Zafar - Bil'),
                    'Amir - Ansh' => array('value'=>'Amir - Ansh'),
                    'Khan - Bala' => array('value'=>'Khan - Bala'),
                    'Majid - Tyb' => array('value'=>'Majid - Tyb'),
                    'Nick - Faiz' => array('value'=>'Nick - Faiz'),
                    'Raam - Pushkar' => array('value'=>'Raam - Pushkar'),
                    'Rahul - Sandeep' => array('value'=>'Rahul - Sandeep'),
                    'Sid - Puneet' => array('value'=>'Sid - Puneet'),
                    'Zafar - Happy' => array('value'=>'Zafar - Happy')
);
?>