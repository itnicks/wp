<?php
/**
 * Cricboard Settings page
 */
add_action( 'admin_menu', 'cricboard_admin_menu' );
function cricboard_admin_menu() {
    add_options_page( __('Cricboard Plugin Options', 'cricboard' ), __('Cricboard Plugin Options', 'cricboard' ), 'manage_options', 'cricboard-plugin', 'cricboard_options_page' );
}

add_action( 'admin_init', 'cricboard_admin_init' );
function cricboard_admin_init() {
   
  	register_setting( 'cricboard-settings-group', 'cricboard-plugin-settings' );
	 
  	add_settings_section( 'section-1', __( 'Cricboard Twitter API Keys', 'cricboard' ), 'cricboard_section_1_callback', 'cricboard-plugin' );
    add_settings_section( 'section-2', __( 'Cricboard Leaderboard Settings', 'cricboard' ), 'cricboard_section_2_callback', 'cricboard-plugin' );

  	add_settings_field( 'consumer_key', __( 'Consumer Key', 'cricboard' ), 'consumer_key_callback', 'cricboard-plugin', 'section-1' );
    add_settings_field( 'consumer_secret', __( 'Consumer Secret', 'cricboard' ), 'consumer_secret_callback', 'cricboard-plugin', 'section-1' );
    add_settings_field( 'oauth_token', __( 'OAuth Token', 'cricboard' ), 'oauth_token_callback', 'cricboard-plugin', 'section-1' );
    add_settings_field( 'oauth_token_secret', __( 'OAuth Token Secret', 'cricboard' ), 'oauth_token_secret_callback', 'cricboard-plugin', 'section-1' );
    add_settings_field( 'stats_limit', __( 'Ranking Limit', 'cricboard' ), 'stats_limit_callback', 'cricboard-plugin', 'section-2' );
	
}

function cricboard_options_page() {
?>
  <div class="wrap">
      <h2><?php _e('Cricboard Plugin Options', 'cricboard'); ?></h2>
      <form action="options.php" method="POST">
        <?php settings_fields('cricboard-settings-group'); ?>
        <?php do_settings_sections('cricboard-plugin'); ?>
        <?php submit_button(); ?>
      </form>
  </div>
<?php }

function cricboard_section_1_callback() {
}
function cricboard_section_2_callback() {
}

function consumer_key_callback() {	
	$settings = (array) get_option( 'cricboard-plugin-settings' );
	$field = "consumer_key";
	$value = esc_attr( $settings[$field] );
	
	echo "<input type='text' name='cricboard-plugin-settings[$field]' value='$value' />";
}

function consumer_secret_callback() {	
	$settings = (array) get_option( 'cricboard-plugin-settings' );
	$field = "consumer_secret";
	$value = esc_attr( $settings[$field] );
	
	echo "<input type='text' name='cricboard-plugin-settings[$field]' value='$value' />";
}

function oauth_token_callback() {	
	$settings = (array) get_option( 'cricboard-plugin-settings' );
	$field = "oauth_token";
	$value = esc_attr( $settings[$field] );
	
	echo "<input type='text' name='cricboard-plugin-settings[$field]' value='$value' />";
}

function oauth_token_secret_callback() {	
	$settings = (array) get_option( 'cricboard-plugin-settings' );
	$field = "oauth_token_secret";
	$value = esc_attr( $settings[$field] );
	
	echo "<input type='text' name='cricboard-plugin-settings[$field]' value='$value' />";
}

function stats_limit_callback() {	
	$settings = (array) get_option( 'cricboard-plugin-settings' );
	$field = "stats_limit";
	$value = intval(esc_attr( $settings[$field] ));
    if($value == "" || $value == 0) $value = CRICBOARD_STATS_LIMIT;
	
	echo "<input type='number' name='cricboard-plugin-settings[$field]' value='$value' />";
}
?>