<?php
/*
Plugin Name: Legacy Update OT
Plugin URI: http://wordpress.org/plugins/legacy_update_ot/
Description: Plugin to maintain leaderboards in online cricket leagues
Author: itnicks
Author URI: http://www.itnicks.com/
Version: 1.0
Text Domain: legacy_update_ot
*/
require_once(plugin_dir_path(__FILE__).'legacy_update_data.php');

/**
 * Cricboard Settings page
 */
add_action( 'admin_menu', 'legacy_update_ot_admin_menu' );
function legacy_update_ot_admin_menu() {
    add_options_page( __('Legacy Update OT Plugin Options', 'legacy_update_ot' ), __('Legacy Update OT Plugin Options', 'legacy_update_ot' ), 'manage_options', 'legacy_update_ot-plugin', 'legacy_update_ot_options_page' );
}

add_action( 'admin_init', 'legacy_update_ot_admin_init' );
function legacy_update_ot_admin_init() {
   
  	register_setting( 'legacy_update_ot-settings-group', 'legacy_update_ot-plugin-settings' );
	 
  	add_settings_section( 'section-1', __( 'Start Import', 'legacy_update_ot' ), 'legacy_update_ot_section_1_callback', 'legacy_update_ot-plugin' );

  	add_settings_field( 'import-1', '', 'import_1_callback', 'legacy_update_ot-plugin', 'section-1' );
	
}

function legacy_update_ot_options_page() {
?>
  <div class="wrap">
      <h2><?php _e('Legacy Update Plugin Options', 'legacy_update_ot'); ?></h2>

        <?php settings_fields('legacy_update_ot-settings-group'); ?>
        <?php do_settings_sections('legacy_update_ot-plugin'); ?>
  </div>
<?php }

function legacy_update_ot_section_1_callback() {
}

function import_1_callback() {
    
	echo "<button id='legacy_ot_update_submit' name='legacy_ot_update_submit'>Import</button>";
    echo '<input type="hidden" name="legacy_ot_ajax_url" id="legacy_ot_ajax_url" value="'.admin_url('admin-ajax.php').'" />';
}

function legacy_import_js() {
    ?>
    <script type="text/javascript">
        jQuery( document ).ready(function( $ ){
            jQuery("#legacy_ot_update_submit").click(function() {
                var ajax_url = $('#legacy_ot_ajax_url').val();
                var data = {
                    'action': 'legacy_import_action'
                };
                jQuery.post(ajax_url, data, function(response) {
                    alert('Import completed');
                });
            });
        });
    </script>
    <?php
}
add_action('admin_footer', 'legacy_import_js');

function legacy_import() {    
    global $data;
    foreach($data as $entry) {
        $entry_arr = explode("|", $entry);
        $username = $entry_arr[0];
        $postid = $entry_arr[1];
        $win_runs = $entry_arr[2];
        $win_wickets = $entry_arr[3];
        $win_overs = $entry_arr[4];
        $opponent = $entry_arr[5];
        $loser_runs = $entry_arr[6];
        $loser_wickets = $entry_arr[7];
        $loser_overs = $entry_arr[8];
        $winner_user = get_user_by('login', $username);        
        $winner = $winner_user->ID;
        $winner_name = $winner_user->user_nicename;
        $loser_user = get_user_by('login', $opponent);
        $loser = $loser_user->ID;
        $loser_name = $loser_user->user_nicename;
        
        $comment_txt = $winner_name.': Runs - '.$win_runs.', Wickets - '.$win_wickets.', Overs - '.$win_overs."\n";
        $comment_txt .= $loser_name.': Runs - '.$loser_runs.', Wickets - '.$loser_wickets.', Overs - '.$loser_overs."\n";

        $commentdata = array(
            'comment_post_ID' => $postid,
            'comment_content' => $comment_txt,
            'user_id' => $winner
        );
        $comment_id = wp_insert_comment( $commentdata );
        
        add_comment_meta( $comment_id, 'opponent', $loser );
        add_comment_meta( $comment_id, 'my_runs', $win_runs );
        add_comment_meta( $comment_id, 'my_wickets', $win_wickets );
        add_comment_meta( $comment_id, 'my_overs', $win_overs );
        add_comment_meta( $comment_id, 'opp_runs', $loser_runs );
        add_comment_meta( $comment_id, 'opp_wickets', $loser_wickets );
        add_comment_meta( $comment_id, 'opp_overs', $loser_overs );
    }
}
add_action('wp_ajax_legacy_import_action', 'legacy_import');

?>