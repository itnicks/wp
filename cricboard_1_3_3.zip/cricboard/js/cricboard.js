/**
 * Cricboard JS
 */
(function( $ ) {
	//Move upload form before runs box
	$(".comment-form-attachment").insertBefore(".my_runs-field");
	
    $("#league-filter").change(function() {
        var selectedVal = $(this).children('option:selected').val();        
        if(selectedVal == "") {
            $(".leaderboard-container .leaderboard-row").removeClass('hide-league');
        } else {
            $(".leaderboard-container .leaderboard-row").each(function() {
                if($(this).attr("data-league") != selectedVal) {
                    $(this).addClass('hide-league');
                } else {
                    $(this).removeClass('hide-league');
                }
            });
        }
    });
    
    $("#opponent-filter").change(function() {
        var selectedVal = $(this).children('option:selected').val();        
        if(selectedVal == "") {
            $(".leaderboard-container .leaderboard-row").removeClass('hide-opponent');
        } else {
            $(".leaderboard-container .leaderboard-row").each(function() {
                if($(this).attr("data-opponent") != selectedVal) {
                    $(this).addClass('hide-opponent');
                } else {
                    $(this).removeClass('hide-opponent');
                }
            });
        }
    });
	
	$("#player-filter").change(function() {
        var selectedVal = $(this).children('option:selected').val();        
        if(selectedVal == "") {
            $(".leaderboard-container .leaderboard-row").removeClass('hide-player');
        } else {
            $(".leaderboard-container .leaderboard-row").each(function() {
                if($(this).attr("data-player") != selectedVal && $(this).attr("data-opponent") != selectedVal) {
                    $(this).addClass('hide-player');
                } else {
                    $(this).removeClass('hide-player');
                }
            });
        }
    });
	
	//Comment Like Ajax
    $('.comment-like-button').click(function() {
        var ajax_url = $('#cricboard_ajax_url').val();
        var comment_id = $(this).attr('id').replace('comment-like-button-','');
        var username = $(this).attr('data-attr');
        
        var data = {
            'action': 'cricboard_comment_like',
            'comment_id': comment_id,
            'user_name': username
        };
        jQuery.post(ajax_url, data, function(response) {
            var ajaxResponse = response.split('|');
            $('#comment-like-count-' + comment_id).text(ajaxResponse[0]);
            $('#comment-like-list-' + comment_id).text(ajaxResponse[1]);
		});
    });
    
    $('.comment-like-count').click(function() {
        $(this).parent().parent().parent().children('.comment-like-list').slideDown(500);
    });
	
	//Delete comment Ajax
    $('.comment-delete-button').click(function() {
        var ajax_url = $('#cricboard_ajax_url').val();
        var comment_id = $(this).attr('data-attr');
		var author_id = $(this).attr('author-attr');

        var data = {
            'action': 'cricboard_comment_delete',
            'comment_id': comment_id,
            'author_id': author_id
        };
        jQuery.post(ajax_url, data, function(response) {
			if(response != '0' && response != 0 && response != '') {
				window.location.href = response;
			}
		});
    });
	
	$(window).load(function() {
		
		//Tablesorter init
		$('.leaderboard-container').each(function() {
			var id = $(this).attr('id');
			$('#' + id).tablesorter();
		});		
		
		//Countdown timer
		var deadline = $('#deadline').val();		
		
		if(deadline != "" && typeof deadline !== 'undefined') {
				var deadline_vals = deadline.split("-");
				var day = parseInt(deadline_vals[0]);
				var month = parseInt(deadline_vals[1]);
				var year = parseInt(deadline_vals[2]);
				
				//var countDownDate = new Date(year, (month-1), day).getTime();
				var countDownDate = new Date(year, (month-1), day);
				var serverCountDownDate = convertToServerTimeZone(countDownDate);
				
				// Update the count down every 1 second
				var x = setInterval(function() {		
				
				// Get todays date and time
				//var now = new Date().getTime();
				var now = new Date();
				var serverNow = convertToServerTimeZone(now);
				
				// Find the distance between now and the count down date
				//var distance = countDownDate - now;
				var distance = serverCountDownDate - serverNow;
				
				// Time calculations for days, hours, minutes and seconds
				var days = Math.floor(distance / (1000 * 60 * 60 * 24));
				var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
				var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
				var seconds = Math.floor((distance % (1000 * 60)) / 1000);
				
				// Display the result in the element with id="demo"
				document.getElementById("deadline_placeholder").innerHTML = days + " Day(s) " + hours + " Hour(s) " + minutes + " Minute(s) " + seconds + " Second(s) Left";
				
				// If the count down is finished, write some text 
				if (distance < 0) {
				  clearInterval(x);
				  document.getElementById("deadline_placeholder").innerHTML = "Expired";
				}
			}, 1000);
		}
	});
	
	function convertToServerTimeZone(inputDateTime){
		offset = -5.0;
		utc = inputDateTime.getTime() + (inputDateTime.getTimezoneOffset() * 60000);
		serverDate = new Date(utc + (3600000*offset));
		return serverDate;
	}
})( jQuery );