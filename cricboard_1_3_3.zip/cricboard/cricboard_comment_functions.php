<?php
/**
 * Customize comment form
 */

function cricboard_add_comment_fields() {
    if(get_post_type(get_the_ID()) == 'league' ) {
        $user_list = cricboard_dropdown_list(cricboard_users(get_current_user_id()), 'ID', 'display_name');
        $bid_list = cricboard_dropdown_list(cricboard_bid_list(), 'key', 'value');
        $bid_points = intval(get_post_meta(get_the_ID(), 'bid_points', true));
        echo cricboard_output_field('user', 'select', __('Opponent', 'cricboard'), '', $user_list, true);
        if($bid_points > 0) {
            echo cricboard_output_field('bid_result', 'select', __('Bid Result', 'cricboard'), '', $bid_list, false);
        }        

        echo cricboard_output_field('my_runs', 'number', __('My Runs', 'cricboard'), '', array(), false);
        echo cricboard_output_field('my_wickets', 'number', __('My Wickets Lost', 'cricboard'), '', array(), false);
        echo cricboard_output_field('my_overs', 'number', __('My Overs Played', 'cricboard'), '', array(), false);
        echo cricboard_output_field('opp_runs', 'number', __('Opponent Runs', 'cricboard'), '', array(), false);
        echo cricboard_output_field('opp_wickets', 'number', __('Opponent Wickets Lost', 'cricboard'), '', array(), false);
        echo cricboard_output_field('opp_overs', 'number', __('Opponent Overs Played', 'cricboard'), '', array(), false);
        echo cricboard_output_field('add_comments', 'textarea', __('Additional Comment', 'cricboard'), '', array(), false);
    }
}
add_action('comment_form_logged_in_after', 'cricboard_add_comment_fields');

//Verify additional comment fields
function cricboard_verify_comment_fields($commentdata) {
    $comment_txt = $commentdata['comment_content'];
    if(get_post_type($_POST['comment_post_ID']) == 'league') {
        if(trim($_POST['user']) == "") wp_die(__('Please select your opponent', 'cricboard'));
        $max_matches_allowed = get_post_meta($_POST['comment_post_ID'], 'match_limit', true);
        $matches_played = cricboard_total_matches(get_current_user_id(), $_POST['comment_post_ID'], $_POST['user']);        
        $max_matches_allowed = get_post_meta($_POST['comment_post_ID'], 'match_limit', true);
        if($max_matches_allowed == "" || $max_matches_allowed == 0) $max_matches_allowed = CRICBOARD_MAX_GAMES;
        if($matches_played >= $max_matches_allowed) wp_die(sprintf(__('You already played %s matches with %s','cricboard'), $matches_played, cricboard_user_display_name($_POST['user'])));
        
        $max_overs = get_post_meta($_POST['comment_post_ID'], 'max_overs', true);
        if($max_overs == "" || $max_overs == 0) $max_overs = CRICBOARD_MAX_OVERS;
        $max_wickets = get_post_meta($_POST['comment_post_ID'], 'max_wickets', true);
        if($max_wickets == "" || $max_wickets == 0) $max_wickets = CRICBOARD_MAX_WICKETS;
        
        if(trim($_POST['my_runs']) != "" && !is_integer(intval(trim($_POST['my_runs'])))) wp_die(__('Please enter a numeric value for runs scored', 'cricboard'));
        
        if(trim($_POST['my_overs']) != "" && !is_numeric(trim($_POST['my_overs']))) {
            wp_die(__('Please enter a numeric value for my overs played', 'cricboard'));
        } elseif(floatval(trim($_POST['my_overs'])) > $max_overs) {
            wp_die(sprintf(__('My Overs Played cannot be more than %s','cricboard'), $max_overs));
        }
        if(trim($_POST['my_wickets']) != "" && !is_integer(intval(trim($_POST['my_wickets'])))) {
            wp_die(__('Please enter a numeric value for wickets lost', 'cricboard'));
        } elseif(floatval(trim($_POST['my_wickets'])) > $max_wickets) {
            wp_die(sprintf(__('My Wickets Lost cannot be more than %s','cricboard'), $max_wickets));
        }
        
        if(trim($_POST['opp_runs']) != "" && !is_integer(intval(trim($_POST['opp_runs'])))) wp_die(__('Please enter a numeric value for opponent&apos;s runs scored', 'cricboard'));
        if(trim($_POST['opp_overs']) != "" && !is_numeric(trim($_POST['opp_overs']))) {
            wp_die(__('Please enter a numeric value for opponent&apos;s overs played', 'cricboard'));
        } elseif(floatval(trim($_POST['opp_overs'])) > $max_overs) {
            wp_die(sprintf(__('Opponent&apos;s Overs Played cannot be more than %s','cricboard'), $max_overs));
        }
        if(trim($_POST['opp_wickets']) != "" && !is_integer(intval(trim($_POST['opp_wickets'])))) {
            wp_die(__('Please enter a numeric value for opponent&apos;s wickets lost', 'cricboard'));
        } elseif(floatval(trim($_POST['opp_wickets'])) > $max_wickets) {
            wp_die(sprintf(__('Opponent&apos;s wickets lost cannot be more than %s','cricboard'), $max_wickets));
        }
        
        $opponent_name = cricboard_user_display_name($_POST['user']);
        $new_games_played = ($matches_played + 1);
        
        if($_POST['bid_result'] == "won")
            $bid_result_txt = __('Won Bid', 'cricboard')."\n";
        elseif($_POST['bid_result'] == "lost")
            $bid_result_txt = __('Lost Bid', 'cricboard')."\n";                    
        
        $comment_txt = __('Game: ','cricboard').$new_games_played."\n";
        $comment_txt .= cricboard_user_display_name(get_current_user_id()).': Runs - '.trim($_POST['my_runs']).', Wickets - '.trim($_POST['my_wickets']).', Overs - '.trim($_POST['my_overs'])."\n";
        $comment_txt .= $opponent_name.': Runs - '.trim($_POST['opp_runs']).', Wickets - '.trim($_POST['opp_wickets']).', Overs - '.trim($_POST['opp_overs'])."\n";
        $comment_txt .= "\n".trim($_POST['add_comments']);            
    }
    $commentdata['comment_content'] = esc_attr($comment_txt);
    return $commentdata;
}
add_filter('preprocess_comment', 'cricboard_verify_comment_fields');

//Prefill comment field upon post
function cricboard_prefill_comment_field($comment_field) {
    if(get_post_type(get_the_ID()) == 'league') {
        $comment_field = '<p class="league-form-comment"><label for="comment">'.__('Comment','cricboard').'</label> <textarea id="comment" name="comment" cols="45" rows="8" maxlength="65525" required="required">'.__('Won against','cricboard').'</textarea></p>';
    }
    return $comment_field;
}
add_filter('comment_form_field_comment', 'cricboard_prefill_comment_field');

//Save comment meta
function cricboard_save_commentmeta($comment_id) {
    $opponent = wp_filter_nohtml_kses($_POST['user']);
    $my_runs = wp_filter_nohtml_kses($_POST['my_runs']);
    $my_overs = wp_filter_nohtml_kses($_POST['my_overs']);
    $my_wickets = wp_filter_nohtml_kses($_POST['my_wickets']);
    $opp_runs = wp_filter_nohtml_kses($_POST['opp_runs']);
    $opp_overs = wp_filter_nohtml_kses($_POST['opp_overs']);
    $opp_wickets = wp_filter_nohtml_kses($_POST['opp_wickets']);
    $bid_result = wp_filter_nohtml_kses($_POST['bid_result']);
    $my_team = wp_filter_nohtml_kses($_POST['my_team']);
    add_comment_meta($comment_id, 'opponent', $opponent);
    if(isset($my_runs)) add_comment_meta($comment_id, 'my_runs', $my_runs);
    if(isset($my_overs)) add_comment_meta($comment_id, 'my_overs', $my_overs);
    if(isset($my_wickets)) add_comment_meta($comment_id, 'my_wickets', $my_wickets);
    if(isset($opp_runs)) add_comment_meta($comment_id, 'opp_runs', $opp_runs);
    if(isset($opp_overs)) add_comment_meta($comment_id, 'opp_overs', $opp_overs);
    if(isset($opp_wickets)) add_comment_meta($comment_id, 'opp_wickets', $opp_wickets);
    if(isset($bid_result)) add_comment_meta($comment_id, 'bid_result', $bid_result);
    if(isset($my_team)) add_comment_meta($comment_id, 'my_team', $my_team);
    
    $comment_obj = get_comment($comment_id);
    $title = get_the_title($comment_obj->comment_post_ID);
    $comment_twt_data = $title.': '.cricboard_user_display_name(get_current_user_id()).' won against '.cricboard_user_display_name($opponent)."\n";
    $comment_twt_data .= cricboard_user_display_name(get_current_user_id()).': Runs - '.$my_runs.', Wickets - '.$my_wickets.', Overs - '.$my_overs."\n";
    $comment_twt_data .= cricboard_user_display_name($opponent).': Runs - '.$opp_runs.', Wickets - '.$opp_wickets.', Overs - '.$opp_overs."\n";
    $img = $_FILES["attachment"]["tmp_name"];
    cricboard_send_to_twitter($comment_twt_data, $img);
}
add_action('comment_post', 'cricboard_save_commentmeta');

/**
 * Modify comment title based on custom post type
 */
function cricboard_custom_comment_form_title( $defaults ){
    if(get_post_type(get_the_ID()) == 'league') {
        $defaults['title_reply'] = __('Post Scorecard', 'cricboard');
        $defaults['logged_in_as'] = null;
    }
    return $defaults;
}
add_filter('comment_form_defaults', 'cricboard_custom_comment_form_title', 20);

/**
 * Comment HTML callback
 */
function cricboard_comment_callback($comment, $args, $depth) {
    $comment_id = get_comment_ID();
    $author_avatar = get_avatar($comment, $args['avatar_size']); 
    $opponent_id = get_comment_meta($comment_id, 'opponent', true);
    $opponent_name = cricboard_user_display_name($opponent_id);
    $opponent_avatar = get_avatar($opponent_id, $args['avatar_size']);
    $logged_in_user = cricboard_user_display_name(get_current_user_id());
    $attachmentId = get_comment_meta(get_comment_ID(), 'attachmentId', TRUE);
    $comment_author_data = get_user_by('email', $comment->comment_author_email);
    $comment_author_id = $comment_author_data->ID;
    $matches_played = cricboard_total_matches($comment_author_id, $comment->comment_post_ID, $opponent_id);
	?>
	<div class="cricboard-comment" id="comment-<?php comment_ID() ?>">
        <div class="cricboard-comment-meta">
            <div class="cricboard-comment-author">
                <?php echo $author_avatar; ?><?php echo get_comment_author_link(); ?>
            </div>
            <div class="cricboard-comment-result"><?php _e('won against','cricboard'); ?></div>
            <div class="cricboard-comment-opponent">
                <?php echo $opponent_avatar; ?><?php echo isset($opponent_name) ? $opponent_name : 'Opponent'; ?>
            </div>
        </div>
        <div class="cricboard-comment-date">
            <a href="<?php echo htmlspecialchars(get_comment_link($comment->comment_ID)); ?>"><?php
                /* translators: 1: date, 2: time */
                printf( 
                    __('%1$s at %2$s'), 
                    get_comment_date(),  
                    get_comment_time() 
                ); ?>
            </a>
        </div>        
        <div class="cricboard-comment-content">
        <?php comment_text(); ?>
        <p></p>
		</div>
        <div class="cricboard-comment-footer">
            <div class="comment-likes">
                <a id="comment-like-count-<?php echo $comment->comment_ID; ?>" class="comment-like-count" href="javascript:void(0)"><?php echo cricboard_comment_likes($comment->comment_ID); ?></a>                
            </div>
            <?php if(is_user_logged_in()): ?>
            <div class="comment-like-button-section">                
                <a class="comment-like-button" data-attr="<?php echo $logged_in_user; ?>" id="comment-like-button-<?php echo $comment->comment_ID; ?>" href="javascript:void(0)"><span class="icon icon-thumbs-up"></span> <span class="screen-reader-text"><?php _e('Like this','cricboard'); ?></span></a>
                <?php if($comment_author_id == get_current_user_id()): ?>
                <a class="comment-delete-button" author-attr="<?php echo $comment_author_id; ?>" data-attr="<?php echo $comment->comment_ID; ?>" id="comment-delete-button-<?php echo $comment->comment_ID; ?>" href="javascript:void(0)"><span class="icon icon-times"></span> <span class="screen-reader-text"><?php _e('Delete scorecard','cricboard'); ?></span></a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <div id="comment-like-list-<?php echo $comment->comment_ID; ?>" class="comment-like-list">
            <?php
                echo cricboard_get_likes_list($comment->comment_ID);
            ?>
        </div>
	<?php
}

//Calculate comment like count
function cricboard_comment_like_count($comment_id) {
    $likes = get_comment_meta($comment_id, 'likes', true);
    if(isset($likes) && $likes != '') $likes_arr = explode('|', $likes); else $likes_arr = array();
    return count($likes_arr);
}

//Calculate comment likes
function cricboard_comment_likes($comment_id) {
    $count = cricboard_comment_like_count($comment_id);
    if($count == 1) return $count.' '.__('Like','cricboard');
    else return $count.' '.__('Likes','cricboard');
}

function cricboard_get_likes_list($comment_id) {
    $likes_list = explode('|', get_comment_meta($comment_id, 'likes', true));
    $likes_list_csv = implode(', ', $likes_list);
    if(isset($likes_list_csv) && $likes_list_csv != ''):
    return $likes_list_csv.' '.__('liked this scorecard','cricboard');
    endif;
    return;
}

//Ajax function for comment like
add_action('wp_ajax_cricboard_comment_like', 'cricboard_comment_like');
function cricboard_comment_like() {
    $comment_id = cricboard_sanitize_text($_POST['comment_id']);
    $user_name = cricboard_sanitize_text($_POST['user_name']);
    $likes = get_comment_meta($comment_id, 'likes', true);
    $likes_arr = explode('|', $likes);    
    if(!in_array($user_name, $likes_arr)) {
        $likes = $likes.'|'.$user_name;
        $likes = ltrim($likes, '|');
        update_comment_meta($comment_id, 'likes', $likes);
    }
    $new_val = cricboard_comment_likes($comment_id).'|'.cricboard_get_likes_list($comment_id);
    echo $new_val;
    wp_die();
}

//Ajax function for delete comment
add_action('wp_ajax_cricboard_comment_delete', 'cricboard_delete_comment');
function cricboard_delete_comment() {
    $comment_id = intval(cricboard_sanitize_text($_POST['comment_id']));
    $author_id = intval(cricboard_sanitize_text($_POST['author_id']));
    $comment_data = get_comment($comment_id);
    $post_id = $comment_data->comment_post_ID;
    $rtn_url = get_the_permalink($post_id).'/#comments';
    if(get_current_user_id() == $author_id) {
        wp_delete_comment($comment_id, false);
        echo $rtn_url;
    } else {
        echo '0';
    }
    wp_die();
}

function cricboard_store_ajax_url() {
    ?>
    <input type="hidden" name="cricboard_ajax_url" id="cricboard_ajax_url" value="<?php echo admin_url('admin-ajax.php'); ?>" />
    <?php
}
add_action('wp_footer', 'cricboard_store_ajax_url');

function cricboard_sanitize_text($input) {
    if(isset($input)) {
        return esc_attr(trim($input));
    } else return;
}
?>