<?php
/**
 * Cricboard Init functions
 */
use Abraham\TwitterOAuth\TwitterOAuth;

//Hide User toolbar
show_admin_bar(false);

//Enqueue Scripts
function cricboard_enqueue_scripts() {
    wp_enqueue_script("cricboard-tablesorter-js", plugin_dir_url(__FILE__).'js/jquery.tablesorter.min.js', array('jquery'), CRICBOARD_VERSION, true);
    wp_enqueue_script("cricboard-js", plugin_dir_url(__FILE__).'js/cricboard.js', array('jquery'), CRICBOARD_VERSION, true);
    wp_enqueue_style("cricboard-icon-css", plugin_dir_url(__FILE__).'fonts/icons.css', array(), CRICBOARD_VERSION);    
    wp_enqueue_style("cricboard-css", plugin_dir_url(__FILE__).'css/cricboard.css', array(), CRICBOARD_VERSION);
}
add_action("wp_enqueue_scripts", "cricboard_enqueue_scripts");

//Allow contributor to edit posts
function cricboard_allow_edit_post() {
    $role_obj = get_role('contributor');
    $role_obj->add_cap('edit_others_posts');
}
add_action('admin_init', 'cricboard_allow_edit_post');

//Add login, logout, profile links to main menu
function cricboard_user_links($items) {
    
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $current_url = $protocol.$_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    
    $completed_leagues_begin = '<li class="menu-item-closed-leagues menu-item-has-children"><a href="javascript:void(0)">'.__('Closed Leagues','cricboard').'</a>';

    //Active leagues
    foreach(cricboard_get_leagues() as $league) {
        if(!has_tag('closed', $league['ID'])) {
            if(get_permalink($league['ID']) == $current_url) $menu_class = ' current-menu-item'; else $menu_class = '';
            $items .= '<li class="menu-item-closed-league'.$menu_class.'"><a href="'.get_permalink($league['ID']).'">'.$league['post_title'].'</a></li>';
        }
    }
    
    //Closed leagues
    $completed_leagues = '';
    foreach(cricboard_get_leagues() as $league) {
        if(has_tag('closed', $league['ID'])) {
            if(get_permalink($league['ID']) == $current_url) $menu_class = ' current-menu-item'; else $menu_class = '';
            $completed_leagues .= '<li class="menu-item-closed-league'.$menu_class.'"><a href="'.get_permalink($league['ID']).'">'.$league['post_title'].'</a></li>';
        }
    }
    if($completed_leagues != '') $completed_leagues = $completed_leagues_begin.'<ul>'.$completed_leagues.'</ul></li>';
    
    $items .= $completed_leagues;
    
	if(is_user_logged_in()) {
		$items .= '<li class="menu-item-myprofile"><a target="_blank" href="'.esc_url(get_edit_user_link()).'">'.__('My Profile','cricboard').'</a></li>';
	}
    $items .= '<li class="menu-item-loginout">'.wp_loginout(get_permalink(), false).'</li>';
	return $items;
}
add_filter('wp_nav_menu_items', 'cricboard_user_links', 10, 2);

function cricboard_send_to_twitter($text, $img = null) {
    $settings = (array) get_option('cricboard-plugin-settings');
    $consumer_key = $settings['consumer_key'];
    $consumer_secret = $settings['consumer_secret'];
    $oauth_token = $settings['oauth_token'];
    $oauth_token_secret = $settings['oauth_token_secret'];
    
    if($consumer_key == "" || $consumer_secret == "" || $oauth_token == "" || $oauth_token_secret == "") return;
    
    $connection = new TwitterOAuth($consumer_key, $consumer_secret, $oauth_token, $oauth_token_secret);
    
    if(isset($img) && file_exists($img)) {
        $media = $connection->upload('media/upload', ['media' => $img]);
        $parameters = [
            'status' => $text,
            'media_ids' => $media->media_id_string
        ];
    } else {
        $parameters = [
            'status' => $text
        ];
    }
    $result = $connection->post('statuses/update', $parameters);
}

?>