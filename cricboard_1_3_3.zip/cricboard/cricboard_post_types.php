<?php
/**
 * Cricboard Custom Post Type functions
 */
//Register Post Type - League
function cricboard_register_post_type() {
    $labels = array (
        'name'               => _x('Leagues', 'post type general name','cricboard'),
        'singular_name'      => _x('League', 'post type singular name','cricboard'),
        'add_new'            => _x('Add New', 'league','cricboard'),
        'add_new_item'       => __('Add New League','cricboard'),
        'edit_item'          => __('Edit League','cricboard'),
        'new_item'           => __('New League','cricboard'),
        'all_items'          => __('All Leagues','cricboard'),
        'view_item'          => __('View League','cricboard'),
        'search_items'       => __('Search Leagues','cricboard'),
        'not_found'          => __('No leagues found','cricboard'),
        'not_found_in_trash' => __('No leagues found in the Trash','cricboard'),
        'menu_name'          => __('Leagues','cricboard')
    );
    
    $args = array(
        'labels'          => $labels,
        'public'          => true,
        'menu_position'   => 5,
        'menu_icon'       => plugin_dir_url(__FILE__).'images/league_post_type_icon.png',
        'supports'        => array('title', 'editor', 'thumbnail', 'comments', 'page-attributes'),
        'has_archive'     => true,
        'capability_type' => 'post',
        'hierarchical'    => false,
        'taxonomies'      => array('post_tag','category'),
    );
    register_post_type('league', $args);
}
add_action('init', 'cricboard_register_post_type');

//Add post meta box for post
function cricboard_add_post_meta_box() {
    global $post;
    add_meta_box('match_limit', __('Max number of matches per player', 'cricboard'), 'cricboard_match_limit_meta_box_callback', 'league', 'normal', 'high');
    add_meta_box('win_points', __('Points for Win', 'cricboard'), 'cricboard_win_points_meta_box_callback', 'league', 'normal', 'high');
    add_meta_box('part_points', __('Points for Participation', 'cricboard'), 'cricboard_part_points_meta_box_callback', 'league', 'normal', 'high');
    add_meta_box('bid_points', __('Points for Winning Bid', 'cricboard'), 'cricboard_bid_points_meta_box_callback', 'league', 'normal', 'high');
    add_meta_box('deadline', __('Deadline (DD-MM-YYYY)', 'cricboard'), 'cricboard_deadline_meta_box_callback', 'league', 'normal', 'high');
    add_meta_box('max_overs', __('Max number of overs','cricboard'), 'cricboard_max_overs_meta_box_callback', 'league', 'normal', 'high');
    add_meta_box('max_wickets', __('Max number of wickets','cricboard'), 'cricboard_max_wickets_meta_box_callback', 'league', 'normal', 'high');
    if(has_tag('teams', $post->ID)) {
        add_meta_box('teams', __('Teams', 'cricboard'), 'cricboard_teams_meta_box_callback', 'league', 'normal', 'high');
        add_meta_box('team_list', __('Team Names (Comma separated)', 'cricboard'), 'cricboard_team_list_meta_box_callback', 'league', 'normal', 'high');
    }
}
add_action('add_meta_boxes', 'cricboard_add_post_meta_box');

function cricboard_match_limit_meta_box_callback() {
    global $post;
    wp_nonce_field('match_limit_nonce', 'match_limit_nonce');
    $value = get_post_meta($post->ID, 'match_limit', true);
    if($value == "") $value = CRICBOARD_MAX_GAMES;
    echo cricboard_output_field('match_limit', 'number', '', esc_attr($value));
}

function cricboard_win_points_meta_box_callback() {
    global $post;
    wp_nonce_field('win_points_nonce', 'win_points_nonce');
    $value = get_post_meta($post->ID, 'win_points', true);
    if($value == "") $value = CRICBOARD_WIN_POINTS;
    echo cricboard_output_field('win_points', 'number', '', esc_attr($value));
}

function cricboard_part_points_meta_box_callback() {
    global $post;
    wp_nonce_field('part_points_nonce', 'part_points_nonce');
    $value = get_post_meta($post->ID, 'part_points', true);
    if($value == "") $value = CRICBOARD_PART_POINTS;
    echo cricboard_output_field('part_points', 'number', '', esc_attr($value));
}

function cricboard_bid_points_meta_box_callback() {
    global $post;
    wp_nonce_field('bid_points_nonce', 'bid_points_nonce');
    $value = get_post_meta($post->ID, 'bid_points', true);
    if($value == "") $value = CRICBOARD_BID_POINTS;
    echo cricboard_output_field('bid_points', 'number', '', esc_attr($value));
}

function cricboard_deadline_meta_box_callback() {
    global $post;
    wp_nonce_field('deadline_nonce', 'deadline_nonce');
    $value = get_post_meta($post->ID, 'deadline', true);    
    echo cricboard_output_field('deadline', 'text', '', esc_attr($value));
}

function cricboard_max_overs_meta_box_callback() {
    global $post;
    wp_nonce_field('max_overs_nonce', 'max_overs_nonce');
    $value = get_post_meta($post->ID, 'max_overs', true);
    if($value == "") $value = CRICBOARD_MAX_OVERS;
    echo cricboard_output_field('max_overs', 'number', '', esc_attr($value));
}

function cricboard_max_wickets_meta_box_callback() {
    global $post;
    wp_nonce_field('max_wickets_nonce', 'max_wickets_nonce');
    $value = get_post_meta($post->ID, 'max_wickets', true);
    if($value == "") $value = CRICBOARD_MAX_WICKETS;
    echo cricboard_output_field('max_wickets', 'number', '', esc_attr($value));
}

function cricboard_teams_meta_box_callback() {
    global $post, $tag_teams;
    $all_users = cricboard_users();
    $team_list = cricboard_to_label_val_arr(explode(',', get_post_meta($post->ID, 'team_list', true)));
    foreach($all_users as $user_entry) {
        $value = get_post_meta($post->ID, 'team_'.$user_entry['ID'], true);
        echo cricboard_output_field('team_'.$user_entry['ID'], 'select', $user_entry['display_name'], $value, cricboard_dropdown_list($team_list, 'value', 'value'));
    }
}

function cricboard_team_list_meta_box_callback() {
    global $post;
    wp_nonce_field('team_list_nonce', 'team_list_nonce');
    $value = get_post_meta($post->ID, 'team_list', true);
    echo cricboard_output_field('team_list', 'text', '', esc_attr($value));
}

//Save meta info
function cricboard_post_meta_save($post_id) {    
    // Check if our nonce is set.
    if(!isset($_POST['match_limit_nonce']) && !isset($_POST['win_points_nonce']) && !isset($_POST['part_points_nonce']) && !isset($_POST['bid_points_nonce']) && !isset($_POST['deadline_nonce']) && !isset($_POST['max_overs_nonce']) && !isset($_POST['max_wickets_nonce']) && !isset($_POST['team_list_nonce'])) {
        return;
    }
    
    // Verify that the nonce is valid.
    if(!wp_verify_nonce( $_POST['match_limit_nonce'], 'match_limit_nonce') && !wp_verify_nonce($_POST['win_points_nonce'], 'win_points_nonce') && !    wp_verify_nonce($_POST['part_points_nonce'], 'part_points_nonce') && !wp_verify_nonce($_POST['bid_points_nonce'], 'bid_points_nonce') && !    wp_verify_nonce($_POST['deadline_nonce'], 'deadline_nonce') && !wp_verify_nonce($_POST['max_overs_nonce'], 'max_overs_nonce') && !wp_verify_nonce($_POST['max_wickets_nonce'], 'max_wickets_nonce') && !wp_verify_nonce($_POST['team_list_nonce'], 'team_list_nonce')) {
        return;
    }
    
    //If no values are set then return
    if(!isset($_POST['match_limit']) && !isset($_POST['win_points']) && !isset($_POST['part_points']) && !isset($_POST['bid_points']) && !isset($_POST['deadline']) && !isset($_POST['max_overs']) && !isset($_POST['max_wickets']) && !isset($_POST['team_list'])) {
        return;
    }
    
    $match_limit = intval(sanitize_text_field($_POST['match_limit']));
    $win_points = intval(sanitize_text_field($_POST['win_points']));
    $part_points = intval(sanitize_text_field($_POST['part_points']));
    $bid_points = intval(sanitize_text_field($_POST['bid_points']));
    $deadline = cricboard_sanitize_date_format(sanitize_text_field($_POST['deadline']));
    $max_overs = intval(sanitize_text_field($_POST['max_overs']));
    $max_wickets = intval(sanitize_text_field($_POST['max_wickets']));
    $team_list = sanitize_text_field($_POST['team_list']);
    
    if($match_limit == "" || $match_limit == 0) $match_limit = CRICBOARD_MAX_GAMES;
    if($max_overs == "" || $max_overs == 0) $max_overs = CRICBOARD_MAX_OVERS;
    if($max_wickets == "" || $max_wickets == 0) $max_wickets = CRICBOARD_MAX_WICKETS;

    // Update the meta field in the database.
    update_post_meta($post_id, 'match_limit', esc_attr($match_limit));
    update_post_meta($post_id, 'win_points', esc_attr($win_points));
    update_post_meta($post_id, 'part_points', esc_attr($part_points));
    update_post_meta($post_id, 'bid_points', esc_attr($bid_points));
    update_post_meta($post_id, 'deadline', esc_attr($deadline));
    update_post_meta($post_id, 'max_overs', esc_attr($max_overs));
    update_post_meta($post_id, 'max_wickets', esc_attr($max_wickets));
    update_post_meta($post_id, 'team_list', esc_attr($team_list));

    $all_users = cricboard_users();
    if(has_tag('teams', $post_id)) {
        foreach($all_users as $user_entry) {
            update_post_meta($post_id, 'team_'.$user_entry['ID'], esc_attr($_POST['team_'.$user_entry['ID']]));
        }
    }
}
add_action('save_post', 'cricboard_post_meta_save');
?>