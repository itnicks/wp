(function() {
    tinymce.create('tinymce.plugins.accordion_start', {
        init : function(ed, url) {
            ed.addButton('accordion_start', {
                title : 'Insert Accordion Start',
                image : url + '/accordion_start_sc.png',
                onclick : function() {
                    ed.selection.setContent('[accordion_start title=""]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.create('tinymce.plugins.accordion_end', {
        init : function(ed, url) {
            ed.addButton('accordion_end', {
                title : 'Insert Accordion End',
                image : url + '/accordion_end_sc.png',
                onclick : function() {
                    ed.selection.setContent('[accordion_end]');
                }
            });
        },
        createControl : function(n, cm) {
            return null;
        }
    });
    tinymce.PluginManager.add('accordion_start', tinymce.plugins.accordion_start);
    tinymce.PluginManager.add('accordion_end', tinymce.plugins.accordion_end);
})();


