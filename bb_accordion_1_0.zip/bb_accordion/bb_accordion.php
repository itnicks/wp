<?php
/*
Plugin Name: Barebones Accordion
Plugin URI: http://wordpress.org/plugins/bb_accordion/
Description: Plugin to add accordion to content
Author: itnicks
Author URI: http://www.itnicks.com/
Version: 1.0
Text Domain: bb_accordion
*/

define('BB_ACCORDION_VERSION', "1.0");

//Enqueue Scripts
function bb_enqueue_scripts() {    
    wp_enqueue_script('jquery');
}
add_action("wp_enqueue_scripts", "bb_enqueue_scripts");

/**
 * Get unique ID.
 *
 */
function bb_accordion_unique_id($prefix = '') {
	static $id_counter = 0;
	if (function_exists('wp_unique_id')) {
		return wp_unique_id($prefix);
	}
	return $prefix . (string) ++$id_counter;
}

//Accordion start
function bb_accordion_accordion_start_sc($atts) {
    $id = bb_accordion_unique_id('acc_');
    $a = shortcode_atts(array('title'=>''), $atts);
    $output = '<div id="'.$id.'" class="accordion_section">';
    $output .= '<h5 class="accordion_title"><span class="accordion_icon">+</span>'.$a['title'].'</h5>';
    $output .= '<div class="accordion_content">';
    return $output;
}

//Accordion end
function bb_accordion_accordion_end_sc() {
    $output = '</div>';
    $output .= '</div>';
    return $output;
}

add_shortcode('accordion_start', 'bb_accordion_accordion_start_sc');
add_shortcode('accordion_end', 'bb_accordion_accordion_end_sc');


/* Add shortcode buttons */
function bb_accordion_add_shortcode_button() {
    add_filter('mce_external_plugins', 'bb_accordion_shortcode_button_plugin');
    add_filter('mce_buttons', 'bb_accordion_register_shortcode_button');
}

function bb_accordion_register_shortcode_button($buttons) {
    array_push($buttons,"accordion_start");
    array_push($buttons,"accordion_end");
    return $buttons;
}

function bb_accordion_shortcode_button_plugin($plugin_array) {
    $plugin_array['accordion_start'] = plugin_dir_url(__FILE__).'js/bb_accordion-shortcode-button.js';
    $plugin_array['accordion_end'] = plugin_dir_url(__FILE__).'js/bb_accordion-shortcode-button.js';
    return $plugin_array;
}
add_action('init','bb_accordion_add_shortcode_button');

/**
 * Styling for accordion
 */
function bb_accordion_css() {
    ?>
    <style type="text/css">
        .accordion_section { margin-bottom: 1em; }
        .accordion_title { border: 1px #ccc solid; padding: 0.5em 1em; margin-bottom: 0 !important; cursor: pointer; }
        .accordion_title:hover, .accordion_current { background-color: #333; color: #fff; border-color: #000; }
        .accordion_icon { margin-right: 10px; font-size: 20px; }
        .accordion_content { border: 1px #ccc solid; border-top: 0 none; padding: 1em; margin-bottom: 0; display: none; }
    </style>
    <?php
}
add_action('wp_head', 'bb_accordion_css');

/**
 * Add JS function for animating
 */
function bb_accordion_init() {
    ?>
    <script type="text/javascript">
        (function( $ ) {
            $('.accordion_title').click(function() {
                if($(this).parent().children('.accordion_content').css('display') == 'none') {
                    $(this).parent().children('.accordion_content').slideDown(500);
                    $(this).children('.accordion_icon').text('-');
                    $(this).addClass('accordion_current');
                } else {
                    $(this).parent().children('.accordion_content').slideUp(500);
                    $(this).children('.accordion_icon').text('+');
                    $(this).removeClass('accordion_current');
                }
            });
        })( jQuery );
    </script>
    <?php
}
add_action('wp_footer', 'bb_accordion_init');
?>