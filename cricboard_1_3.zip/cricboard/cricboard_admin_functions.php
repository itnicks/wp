<?php
/**
 * Admin Functions
 */

function cricboard_user_meta_field($user) {
	$psn = esc_attr(get_user_meta($user->ID, 'psn', true));
    ?>
    <table class="form-table">
    <tr class="user-psn-wrap" id="psn-form">
        <th><?php _e('Playstation User (PSN)','cricboard'); ?>:</th>
        <td><?php echo cricboard_output_field('psn', 'text', '', $psn, array(), false); ?></td>
    </tr>
    </table>
    <?php
}
add_action( 'show_user_profile', 'cricboard_user_meta_field' );
add_action( 'edit_user_profile', 'cricboard_user_meta_field' );

function cricinfo_save_user_meta( $user_id ) {
    if ( !current_user_can( 'edit_user', $user_id ) ) { 
        return false; 
    }
    update_user_meta( $user_id, 'psn', $_POST['psn'] );
}
add_action( 'personal_options_update', 'cricinfo_save_user_meta' );
add_action( 'edit_user_profile_update', 'cricinfo_save_user_meta' );

/**
 * Remove unwanted fields
 */
if(is_admin()) {
    remove_action( 'admin_color_scheme_picker', 'admin_color_scheme_picker' );
    add_action( 'personal_options', 'cricboard_hide_personal_options' );
}

function cricboard_remove_contact_methods( $contactmethods ) {
		unset( $contactmethods['aim'] );
		unset( $contactmethods['jabber'] );
		unset( $contactmethods['yim'] );
		
		return $contactmethods;
}
add_filter('user_contactmethods', 'cricboard_remove_contact_methods');

function cricboard_hide_personal_options() {
  ?>
    <script type="text/javascript">
        jQuery( document ).ready(function( $ ){
            $('#your-profile .form-table:first, #your-profile h3:first').remove();
            $(".user-url-wrap").remove();
            $(".user-description-wrap").remove();
            $(".user-sessions-wrap").remove();
            $("#psn-form").insertAfter(".user-display-name-wrap");
						$('.user-profile-picture').remove();
						$('h2').each(function() {
							if($(this).text() == 'About Yourself') $(this).remove();
						});
						$('label').each(function() {
							if($(this).attr('for') == 'wp_user_avatar') {
								$(this).text('Profile Picture');
							}
						});
        });
    </script>
  <?php
}

//Change login page logo
function cricboard_login_logo() {
    $img_src = plugin_dir_url(__FILE__).'images/logo.png';
    
    if($img_src != '') {
        ?>
        <style type="text/css">
            #login h1 a, .login h1 a {
                background-image: url(<?php echo $img_src; ?>);
                height:72px;
                width: auto;
                background-size: auto 72px;
                background-repeat: no-repeat;
                padding-bottom: 30px;
            }
        </style>
        <?php
    }
}
add_action( 'login_enqueue_scripts', 'cricboard_login_logo' );

function cricboard_sanitize_date_format($date) {
		if (preg_match("/^(0[1-9]|[1-2][0-9]|3[0-1])-(0[1-9]|1[0-2])-[0-9]{4}$/",$date)) {
				return $date;
		} else {
				return "";
		}
}

function cricboard_score_update() {
		$matches = cricboard_all_matches();
		$output = '';
		foreach($matches as $entry) {
				$winner = cricboard_user_display_name($entry->user_id);
				$loser = cricboard_user_display_name(get_comment_meta($entry->comment_ID, 'opponent', true));
				$comment_id = $entry->comment_ID;
				$my_runs = get_comment_meta($entry->comment_ID, 'my_runs', true);
				$my_wickets = get_comment_meta($entry->comment_ID, 'my_wickets', true);
				$my_overs = get_comment_meta($entry->comment_ID, 'my_overs', true);
				$opp_runs = get_comment_meta($entry->comment_ID, 'opp_runs', true);
				$opp_wickets = get_comment_meta($entry->comment_ID, 'opp_wickets', true);
				$opp_overs = get_comment_meta($entry->comment_ID, 'opp_overs', true);
				
				$output .= '<p>';
				$output .= '<h4>'.$winner.' won against '.$loser.'</h4>';
				$output .= '<p><a target="_blank" href="'.get_comment_link($entry->comment_ID).'">'.__('View Scorecard','cricboard').'</a></p>';
				$output .= '<form name="score-update-form-'.$comment_id.'" id="score-update-form-'.$comment_id.'" action="'.get_permalink().'" method="post">';
				$output .= __('Winner runs: ','cricboard').'<input id="score-update-myruns" name="score-update-myruns" type="number" value="'.esc_attr($my_runs).'" /><br/><br/>';
				$output .= __('Winner wickets: ','cricboard').'<input id="score-update-mywickets" name="score-update-mywickets" type="number" value="'.esc_attr($my_wickets).'" /><br/><br/>';
				$output .= __('Winner overs: ','cricboard').'<input id="score-update-myovers" name="score-update-myovers" type="number" value="'.esc_attr($my_overs).'" /><br/><br/>';
				$output .= __('Opponent runs: ','cricboard').'<input id="score-update-oppruns" name="score-update-oppruns" type="number" value="'.esc_attr($opp_runs).'" /><br/><br/>';
				$output .= __('Opponent wickets: ','cricboard').'<input id="score-update-oppwickets" name="score-update-oppwickets" type="number" value="'.esc_attr($opp_wickets).'" /><br/><br/>';
				$output .= __('Opponent overs: ','cricboard').'<input id="score-update-oppovers" name="score-update-oppovers" type="number" value="'.esc_attr($opp_overs).'" /><br/><br/>';
				$output .= '<input type="hidden" name="score-update-comment-id" id="score-update-comment-id" value="'.esc_attr($comment_id).'"/>';
				$output .= '<input type="submit" name="score-update-submit" id="score-update-submit" value="'.__('Update','cricboard').'"/>';
				$output .= '</form>';
				$output .= '</p><br/>';
		}
		return $output;
}

function cricboard_save_score_updates() {
		if(isset($_POST['score-update-submit']) && isset($_POST['score-update-comment-id'])) {
				$comment_id = $_POST['score-update-comment-id'];
				$my_runs = get_comment_meta($comment_id, 'my_runs', true);
				$my_wickets = get_comment_meta($comment_id, 'my_wickets', true);
				$my_overs = get_comment_meta($comment_id, 'my_overs', true);
				$opp_runs = get_comment_meta($comment_id, 'opp_runs', true);
				$opp_wickets = get_comment_meta($comment_id, 'opp_wickets', true);
				$opp_overs = get_comment_meta($comment_id, 'opp_overs', true);
				
				$my_runs = cricboard_sanitize_score($_POST['score-update-myruns'], $my_runs);
				$my_wickets = cricboard_sanitize_score($_POST['score-update-mywickets'], $my_wickets);
				$my_overs = cricboard_sanitize_score($_POST['score-update-myovers'], $my_overs);
				$opp_runs = cricboard_sanitize_score($_POST['score-update-oppruns'], $opp_runs);
				$opp_wickets = cricboard_sanitize_score($_POST['score-update-oppwickets'], $opp_wickets);
				$opp_overs = cricboard_sanitize_score($_POST['score-update-oppovers'], $opp_overs);
				
				update_comment_meta($comment_id, 'my_runs', $my_runs);
				update_comment_meta($comment_id, 'my_wickets', $my_wickets);
				update_comment_meta($comment_id, 'my_overs', $my_overs);
				update_comment_meta($comment_id, 'opp_runs', $opp_runs);
				update_comment_meta($comment_id, 'opp_wickets', $opp_wickets);
				update_comment_meta($comment_id, 'opp_overs', $opp_overs);
		}
}
cricboard_save_score_updates();

function cricboard_sanitize_score($val, $default) {
	if(isset($val) && is_numeric($val)) return intval($val); else return $default;
}
?>